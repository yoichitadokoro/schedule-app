// Modules to control application life and create native browser window
'use strict'
const {electron,BrowserWindow,app,ipcMain,Menu,shell} = require('electron');
const path = require('path')
const os = require('os')
const fs = require('fs')

function createWindow () {
  // Create the browser window.
  const mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: true,
    },
    'icon': __dirname + '/aiib8-5q66n-001.ico',
  })

  // and load the index.html of the app.
  mainWindow.loadFile('./src/web/loading.html')
  mainWindow.maximize()

  // Open the DevTools.
  //mainWindow.webContents.openDevTools()
  const templateMenu = [
    {
        label: 'ファイル',
        submenu: [
            {
                role: 'quit',
            },
        ]
    },
    {
        label: '編集',
        submenu: [
            {
                role: 'undo',
            },
            {
                role: 'redo',
            },
        ]
    },
    {
        label: '表示',
        submenu: [
            {
                label: 'Reload',
                accelerator: 'CmdOrCtrl+R',
                click(item, focusedWindow){
                    if(focusedWindow) focusedWindow.reload()
                },
            },
            {
                type: 'separator',
            },
            {
                role: 'resetzoom',
            },
            {
                role: 'zoomin',
            },
            {
                role: 'zoomout',
            },
            {
                type: 'separator',
            },
            {
                role: 'togglefullscreen',
            }
        ]
    }
  ]
  const menu = Menu.buildFromTemplate(templateMenu);
  Menu.setApplicationMenu(menu);
}

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.whenReady().then(() => {
  createWindow()

  app.on('activate', function () {
    // On macOS it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

// Quit when all windows are closed, except on macOS. There, it's common
// for applications and their menu bar to stay active until the user quits
// explicitly with Cmd + Q.
app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit()
})

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.
/*
const Sqlite = require('./sqlite.js')
const sq = new Sqlite()
*/
const Nedb = require('./nedb.js')
const sq = new Nedb()
let datenav = new Date()
let today = new Date()
let curday = date_to_str(today)
let curweek = week_from_day(today)
let curmonth = month_from_day(today)
let bselect = -1
let tabs = 0
let q_belong = []
let q_employee = []
let q_dayschedule = []
let q_weekschedule = []
let q_monthschedule = []
let q_lunch = []
let holiday = []
let bcal = []

const path_emp = "./db/SetEmployee.txt"
const path_data = "./db/data/"
ipcMain.handle("Loading",async (event,arg) => {
  //await createDammy()
  await Loading1()
  return 1
})
async function createDammy(){
    await sq.createBelongtable()
    await sq.createLunchtable()
}
async function Loading1(){
    q_belong = await sq.get_query_belongs()
    q_employee = await sq.get_query_employees()
    holiday = await sq.get_query_allholiday()
    await update_query()
    await set_employee_file()
}
ipcMain.handle("GetBelong", async (event, arg) => {
  return q_belong
});
ipcMain.handle("GetEmployee", async (event, arg) => {
  return q_employee
});
ipcMain.handle("GetDaySchedule", async (event, arg) => {
  return q_dayschedule
});
ipcMain.handle("GetLunch",async(event,arg)=>{
  let d = curday
  if(arg.curday != "") d = arg.curday
  q_lunch = await sq.get_query_lunch(d)
  if(q_lunch==null) q_lunch = {sdate:d,addlunch:0,detlunch:0}
  return q_lunch
})
ipcMain.handle("SetLunch",async(event,arg)=>{
  let d = await sq.update_lunch(arg)
  return d
})
ipcMain.handle("DateChange", async (event, arg) => {
  curday = arg.curday
  curweek = week_from_day(new Date(curday))
  curmonth = month_from_day(new Date(curday))
  await update_query()
  return q_dayschedule
});
ipcMain.handle("ChangeSchedule", async(event,arg) => {
  let ch = await sq.update_dayschedule(arg.name,arg.sdate,arg.changed,arg.ide)
  await update_query()
  return ch
});
ipcMain.handle("DeleteSchedule", async(event,arg) => {
  let ch = await sq.delete_dayschedule(arg.name,arg.sdate,arg.ide)
  await update_query()
  return ch
});
ipcMain.handle("BugSend", async (event, arg) => {
  await sq.new_bugs({txt:arg.txt,created_at:date_to_str(today),sender:os.userInfo().username})
  return arg.txt
});
ipcMain.handle("NewsSend", async (event, arg) => {
  await sq.new_news({txt:arg.txt,created_at:date_to_str(today),sender:os.userInfo().username})
  return arg.txt
});
ipcMain.handle("BugList", async(event,arg)=>{
  let blist = sq.get_query_bugs()
  return blist
})
ipcMain.handle("NewsList", async(event,arg)=>{
  let blist = sq.get_query_news()
  return blist
})
ipcMain.handle("GetHoliday", async(event,arg) => {
  return holiday
});
ipcMain.handle("toHome",async(event,arg)=>{
  curday = date_to_str(today)
  curmonth = month_from_day(today)
  curweek = week_from_day(today)
});
ipcMain.handle("getCurday",async(event,arg)=>{
  return curday
})
ipcMain.handle("SendSelectedBelong",async(event,arg)=>{
  bselect = arg
  return bselect
})
ipcMain.handle("GetSelectedBelong",async(event,arg)=>{
  return bselect
})
ipcMain.handle("GetCurweek",async(event,arg)=>{
  return curweek
})
ipcMain.handle("GetWeekSchedule",async(event,arg)=>{
  return q_weekschedule
})
ipcMain.handle("GetMonth",async(event,arg)=>{
  return curmonth
})
ipcMain.handle("GetMonthSchedule",async(event,arg)=>{
  return q_monthschedule
})
ipcMain.handle("WeekChange",async(event,arg)=>{
  curday = arg.curday
  curweek = week_from_day(new Date(arg.curday))
  curday = curweek[0]
  curmonth = month_from_day(new Date(curday))
  if(curweek.indexOf(date_to_str(today))!=-1) curday = date_to_str(today)
  await update_query()
  //console.log(q_weekschedule)
  return {"sche_w":q_weekschedule,"curweek":curweek}
})
ipcMain.handle("MonthChange",async(event,arg)=>{
  curday = arg.curday
  curmonth = month_from_day(new Date(arg.curday))
  curweek = week_from_day(new Date(arg.curday))
  curday = curmonth[0]
  if(curmonth.indexOf(date_to_str(today))!=-1) curday = date_to_str(today)
  await update_query()
  //console.log(q_monthschedule)
  return {"sche_m":q_monthschedule,"curmonth":curmonth}
})
ipcMain.handle("ChangeWeekSchedule",async(event,arg)=>{
  let mo = arg.edschew1[0].sdate.slice(0,7)
  await sq.conn2(mo)
  for(var i=0;i<arg.edschew1.length;i++){
    let sch = arg.edschew1[i]
    delete sch._id
    if(mo != sch.sdate.slice(0,7)){
      mo = sch.sdate.slice(0,7)
      await sq.conn2(mo)
    }
    await sq.update_dayschedule(arg.edschew1[0].name,sch.sdate,sch,arg.edschew1[0].ide)
  }
  mo = arg.edschew2[0].sdate.slice(0,7)
  await sq.conn2(mo)
  for(var i=0;i<arg.edschew2.length;i++){
    let sch = arg.edschew2[i]
    delete sch._id
    sch.name = arg.edschew1[0].name
    sch.belong = arg.edschew1[0].belong
    sch.idb = arg.edschew1[0].idb
    sch.odr = arg.edschew1[0].odr
    sch.ide = arg.edschew1[0].ide
    if(mo != sch.sdate.slice(0,7)){
      mo = sch.sdate.slice(0,7)
      await sq.conn2(mo)
    }
    if(sch.period == ""){
      await sq.delete_dayschedule(arg.edschew1[0].name,sch.sdate,arg.edschew1[0].ide)
    }else{
      await sq.update_dayschedule(arg.edschew1[0].name,sch.sdate,sch,arg.edschew1[0].ide)
    }
  }
  await update_query()
  return 1
})
ipcMain.handle("ChangeWeekSchedule2",async(event,arg)=>{
  let clist = arg.schelist.sort((a,b) => new Date(a.sdate) - new Date(b.sdate))
  let mo = clist[0].sdate.slice(0,7)
  await sq.conn2(mo)
  for(var i=0;i<clist.length;i++){
    let sch = clist[i]
    if(mo != sch.sdate.slice(0,7)){
      mo = sch.sdate.slice(0,7)
      await sq.conn2(mo)
    }
    await sq.update_dayschedule(sch.name,sch.sdate,sch,sch.ide)
  }
  await update_query()
  return 1
})
ipcMain.handle("UpdateBelong",async(event,arg)=>{
  let bel = arg
  delete bel._id
  let res = await sq.remake_belongs(bel)
  q_belong = await sq.get_query_belongs()
  return res
})

ipcMain.handle("getTodayVue", async (event, arg) => {
  return date_to_str(today)
});
ipcMain.handle("CleanDatabase", async (event, arg) => {
  let twoyearsago = new Date()
  twoyearsago.setFullYear(twoyearsago.getFullYear() - 2)
  let flist = fs.readdirSync(path_data).sort()
  flist = flist.filter((v)=> v.indexOf(".json") != -1 && v < date_to_str(twoyearsago))
  flist.forEach(function(file){
    fs.unlink(path_data+file,function(err){
      if(err){throw(err);}
      console.log(path_data+file+" deleted")
    })
  })
  return flist
});
ipcMain.handle("EmployeeExist",async(event,arg)=>{
  return fs.existsSync( path_emp )
})
ipcMain.handle("SetEmployee",async(event,arg)=>{
  let chdata = arg.changedata
  let deldata = arg.deldata
  delete chdata._id
  delete deldata._id
  if(date_to_str(today) >= arg.dayset){
    if(chdata.length > 0){
      for(var i=0;i<chdata.length;i++){
        await sq.update_employee(chdata[i].ide,chdata[i])
      }
    }
    if(deldata.length > 0){
      for(var i=0;i<deldata.length;i++){
        await sq.delete_employee(deldata[i].ide)
      }
    }
    q_employee = await sq.get_query_employees()
    if(chdata.length > 0 || deldata.length > 0){
      await set_changed_schedule(arg.dayset,chdata,deldata,arg.iskubun,arg.islunch)
    }
  }else{
    try {
      const fd = fs.openSync(path_emp, "w");
      fs.writeSync(fd, arg.dayset);
      fs.writeSync(fd, "\n!\n");
      if(chdata.length > 0){
        for(var i=0;i<chdata.length;i++){
          fs.writeSync(fd, chdata[i].odr+",")
          fs.writeSync(fd, chdata[i].belong+",")
          fs.writeSync(fd, chdata[i].idb+",")
          fs.writeSync(fd, chdata[i].name+",")
          fs.writeSync(fd, chdata[i].ide+",")
          fs.writeSync(fd, chdata[i].tel+",")
          fs.writeSync(fd, chdata[i].memo+",")
          fs.writeSync(fd, chdata[i].slunch+",")
          fs.writeSync(fd, chdata[i].kubun+",")
          fs.writeSync(fd, arg.iskubun[i]+",")
          fs.writeSync(fd, arg.islunch[i])
          fs.writeSync(fd, "\n");
        }
      }
      fs.writeSync(fd,"!\n")
      if(deldata.length > 0){
        for(var i=0;i<deldata.length;i++){
          fs.writeSync(fd, deldata[i].ide+",")
          fs.writeSync(fd, deldata[i].name)
          fs.writeSync(fd, "\n");
        }
      }
      fs.closeSync(fd);
    }
    catch(e){
      console.log(e.message);
    }
  }
  return 0
})
ipcMain.handle("disptest",async(event,arg)=>{
  console.log(arg)
})

ipcMain.handle("HolidayList", async (event, arg) => {
  const sdate = arg + "-01-01"
  const fdate = arg + "-12-31"
  const query = await sq.get_query_holiday(sdate,fdate)
  let hol = []
  for(var i=0;i<query.length;i++){
    hol.push(query[i].day)
  }
  return hol
});
ipcMain.handle("SetHoliday", async (event, arg) => {
  await sq.new_holidays(arg)
  return 1
});
ipcMain.handle("DeleteHoliday", async (event, arg) => {
  await sq.delete_holidays(arg)
  return 1
});

function week_from_day(date){
  let wday = Array(7)
  let wstart = new Date(date)
  if(date.getDay() == 0) wstart.setDate(date.getDate() - 6)
  else wstart.setDate(date.getDate() - (date.getDay()-1))
  for(var i=0;i<7;i++){
    wday[i] = date_to_str(wstart)
    wstart.setDate(wstart.getDate() + 1)
  }
  return wday
}
function month_from_day(date){
  let mday = []
  let mstart = new Date(date.getFullYear(),date.getMonth(),1)
  let mend = new Date(mstart)
  mend.setMonth(mend.getMonth()+1)
  while(mstart < mend){
    mday.push(date_to_str(mstart))
    mstart.setDate(mstart.getDate()+1)
  }
  return mday
}
function date_to_str(date){
  return date.getFullYear() + "-" + ('0' + (date.getMonth() + 1)).slice(-2) + "-" + ('0' + date.getDate()).slice(-2)
}
function str_to_date(str){
  const spt = str.split("-")
  const fmt = new Date(spt[0],parseInt(spt[1]-1),spt[2])
  return fmt
}
function sdate(){
  const date = new Date(datenav.getFullYear(),datenav.getMonth(),-4)
  return date
}
function fdate(){
  const date = new Date(datenav.getFullYear(),datenav.getMonth(),listdays-1)
  return date
}
function maru(f){
  if(f) return "○"
  else return ""
}
function weekday(date){
  const wk = ["日","月","火","水","木","金","土"]
  return wk[date.getDay()]
}
async function get_week_schedule(){
  let mo = curweek[0].slice(0,7)
  let check = false
  await sq.conn2(mo)
  let sche_w = await sq.get_query_weekschedule(curweek)
  let sche_w2 = []
  if(mo != curweek[6].slice(0,7)){
    await sq.conn2(curweek[6].slice(0,7))
    sche_w2 = await sq.get_query_weekschedule(curweek)
    check = true
    sche_w = sche_w.concat(sche_w2)
  }
  return sche_w
}
async function update_query(){
  q_weekschedule = await get_week_schedule()
  await sq.conn2(curday.slice(0,7))
  q_dayschedule = await sq.get_query_dayschedule(curday)
  q_monthschedule = await sq.get_query_monthschedule(curday)
  await check_query()
}
async function check_query(){
  let chksche = []
  let nodatalist = []
  if(!isHoliday(new Date(curday)) && q_dayschedule.length < 1){
    nodatalist.push(curday)
  }
  for(var i=0;i<curweek.length;i++){
    chksche = q_weekschedule.filter((v) => v.sdate === curweek[i])
    if(!isHoliday(new Date(curweek[i])) && chksche.length < 1){
      nodatalist.push(curweek[i])
    }
  }
  for(var i=0;i<curmonth.length;i++){
    chksche = q_monthschedule.filter((v) => v.sdate === curmonth[i])
    if(!isHoliday(new Date(curmonth[i])) && chksche.length < 1){
      nodatalist.push(curmonth[i])
    }
  }
  if(nodatalist.length > 0){
    let nlist = Array.from(new Set(nodatalist)).sort()
    let mo = nlist[0].slice(0,7)
    await sq.conn2(mo)
    console.log("nodatalist:",nlist)
    for(var i=0;i<nlist.length;i++){
      let blank = Array(q_employee.length)
      if(mo != nlist[i].slice(0,7)){
        mo = nlist[i].slice(0,7)
        await sq.conn2(mo)
      }
      for(var j=0;j<q_employee.length;j++){
        let bk = {...q_employee[j]}
        delete bk._id
        bk.sdate = nlist[i]
        bk.alunch = bk.slunch
        blank[j] = {...bk}
      }
      await sq.insert_dayschedule(blank)
    }
    q_weekschedule = await get_week_schedule()
    await sq.conn2(curday.slice(0,7))
    q_dayschedule = await sq.get_query_dayschedule(curday)
    q_monthschedule = await sq.get_query_monthschedule(curday)
  }
}
async function set_changed_schedule(sdate,chdata,deldata,iskubun,islunch){
  let mo = sdate.slice(0,7)
  //await sq.conn2(mo)
  let flist = fs.readdirSync(path_data).sort()
  flist = flist.filter((v)=> v.indexOf(".json") != -1 && v > sdate)
  let ch = Array(chdata.length)
  for(var i=0;i<ch.length;i++){
    ch[i] = {"ide":chdata[i].ide,"name":chdata[i].name,"idb":chdata[i].idb,"belong":chdata[i].belong,"tel":chdata[i].tel,"memo":chdata[i].memo,"odr":chdata[i].odr}
    if(iskubun[i]) ch[i].kubun = chdata[i].kubun
    if(islunch[i]){
      ch[i].slunch = chdata[i].slunch
      ch[i].alunch = chdata[i].slunch
    }
  }
  for(var f=0;f<flist.length;f++){
    mo = flist[f].slice(0,7)
    await sq.conn2(mo)
    for(var i=0;i<ch.length;i++){
      //let query = await sq.get_query_monthschedule2(sdate,ch[i].ide)
      await sq.update_monthschedule(sdate,ch[i].ide,ch[i])
    }
    for(var i=0;i<deldata.length;i++){
      await sq.delete_monthschedule(sdate,deldata[i].ide)
    }
  }
}
async function set_employee_file(){
  if(fs.existsSync(path_emp)){
    let text = fs.readFileSync(path_emp,'utf-8');
    let tx1 = text.split("!")
    const sdate = tx1[0].split("\n")[0]
    console.log(sdate);
    if(sdate <= date_to_str(today)){
      let chdata = []
      let deldata = []
      let iskubun = []
      let islunch = []
      const upd = tx1[1].split("\n")
      if(upd.length > 2){
        for(var i=1;i<upd.length-1;i++){
          const t = upd[i].split(",")
          let todb = {"odr":t[0],"belong":t[1],"idb":t[2],"name":t[3],"ide":t[4],"tel":t[5],"memo":t[6],"slunch":t[7],"kubun":t[8]}
          chdata.push(todb)
          iskubun.push(t[9])
          islunch.push(t[10])
        }
      }
      const del = tx1[2].split("\n")
      if(del.length > 2){
        for(var i=1;i<del.length-1;i++){
          const t = del[i].split(",")
          let todb = {"ide":t[0],"name":t[1]}
          deldata.push(todb)
        }
      }
      //console.log(chdata)
      //console.log(deldata)
      await set_changed_schedule(sdate,chdata,deldata,iskubun,islunch)
      fs.unlink(path_emp, (err) => {
        if (err) throw err;
        console.log('SetEmployee.txt was deleted');
      });
    }
  }
}


function isHoliday(date){
  let hol = []
  hol = holiday.filter((v) => v.day === date_to_str(date))
  if(hol.length>0 || date.getDay()==0 || date.getDay()==6) return true
  else return false
}

function holcolor(date){
  if(date_to_str(date) == date_to_str(today)) return "lightgreen"
  else if(isHoliday(date)) return "lightgray"
  else return ""
}
async function sleep(m){
    return new Promise((resolve,reject) => {
    setTimeout(()=>{resolve()},m)
  })
}
