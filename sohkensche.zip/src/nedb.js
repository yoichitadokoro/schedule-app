const Datastore = require('nedb')
let db = {}
const fname = {
  Holiday:'db/Holiday.json',
  Belong:'db/Belong.json',
  Employee:'db/Employee.json',
  Lunch:'db/Lunch.json',
  Bugs:'db/Bugs.json',
  News:'db/Topics.json'
}

class Nedb{
  conn () {
    if (!db || !db.open) {
      db.BlowMachine = new Datastore({filename:fname.BlowMachine})
      db.BlowSchedule = new Datastore({filename:fname.BlowSchedule})
      db.InjMachine = new Datastore({filename:fname.InjMachine})
      db.InjSchedule = new Datastore({filename:fname.InjSchedule})
      db.Holiday = new Datastore({filename:fname.Holiday})
      db.Belong = new Datastore({filename:fname.Belong})
      db.Employee = new Datastore({filename:fname.Employee})
      db.Lunch = new Datastore({filename:fname.Lunch})
      db.Bugs = new Datastore({filename:fname.Bugs})
      db.News = new Datastore({filename:fname.News})
    }
    return db
  }
  conn2(dbfile){
    const fn = "db/data/" + dbfile + ".json"
    db.DaySchedule = new Datastore({filename:fn})
    return db
  }
  createBelongtable(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Belong.loadDatabase((err)=>{
        if(err) reject(err)
        db.Belong.find({},(err,docs)=>{
          if(err) reject(err)
          if(docs.length == 0){
            const datalist = [
                {idb:1, name:'所長・部長'},
                {idb:2, name:'機能材料研究室'},
                {idb:3, name:'包装材料研究室'},
                {idb:4, name:'生物化学研究室'},
                {idb:5, name:'分析化学研究室'},
                {idb:6, name:'成形加工研究室'},
                {idb:7, name:'情報数理研究室'},
                {idb:8, name:'調査企画室'},
                {idb:9, name:'特許室'},
                {idb:10, name:'事務室'},
                {idb:11, name:'その他'},
            ]
            db.Belong.insert(datalist,(err,newdoc)=>{
              if(err) reject(err)
              resolve(newdoc)
            })
          }else{
            console.log(docs)
            resolve(docs)
          }
        })
      })
    })
  }
  createLunchtable(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Lunch.loadDatabase((err)=>{
        if(err) reject(err)
        db.Lunch.find({},(err,docs)=>{
          if(err) reject(err)
          if(docs.length == 0){
            const datalist = [
                {sdate:"2021-08-03",addlunch:3,detlunch:70},
                {sdate:"2021-08-04",addlunch:2,detlunch:67},
            ]
            db.Lunch.insert(datalist,(err,newdoc)=>{
              if(err) reject(err)
              resolve(newdoc)
            })
          }else{
            console.log(docs)
            resolve(docs)
          }
        })
      })
    })
  }

  get_query_belongs(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Belong.loadDatabase((err)=>{
        if(err) reject(err)
        db.Belong.find({}).sort({idb:1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  get_query_employees(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Employee.loadDatabase((err)=>{
        if(err) reject(err)
        db.Employee.find({}).sort({odr:1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  get_query_dayschedule(d){
    return new Promise((resolve, reject) => {
      db.DaySchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.DaySchedule.find({sdate:d}).sort({odr:1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  update_dayschedule(name,sdate,changed,ide){
    return new Promise((resolve, reject) => {
      db.DaySchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.DaySchedule.update({ide:ide,sdate:sdate},{$set:changed},{upsert:true},(err,rows,upsert)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  delete_dayschedule(name,sdate,ide){
    return new Promise((resolve, reject) => {
      db.DaySchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.DaySchedule.remove({ide:ide,sdate:sdate},{},(err,rows)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  insert_dayschedule(newdocs){
    return new Promise((resolve, reject) => {
      db.DaySchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.DaySchedule.insert(newdocs,(err,rows)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  get_query_lunch(d){
    return new Promise((resolve, reject) => {
      db.Lunch.loadDatabase((err)=>{
        if(err) reject(err)
        db.Lunch.findOne({sdate:d}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  update_lunch(datalist){
    return new Promise((resolve, reject) => {
      db.Lunch.loadDatabase((err)=>{
        if(err) reject(err)
        db.Lunch.update({sdate:datalist.sdate},{$set:datalist},{upsert:true},(err,rows,upsert)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  new_bugs(datalist){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Bugs.loadDatabase((err)=>{
        if(err) reject(err)
        db.Bugs.insert(datalist,(err,rows)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  new_news(datalist){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.News.loadDatabase((err)=>{
        if(err) reject(err)
        db.News.insert(datalist,(err,rows)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  get_query_bugs(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Bugs.loadDatabase((err)=>{
        if(err) reject(err)
        db.Bugs.find({}).sort({created_at:-1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  get_query_news(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.News.loadDatabase((err)=>{
        if(err) reject(err)
        db.News.find({}).sort({created_at:-1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  get_query_allholiday(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Holiday.loadDatabase((err)=>{
        if(err) reject(err)
        db.Holiday.find({},(err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  get_query_weekschedule(d){
    return new Promise((resolve, reject) => {
      db.DaySchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.DaySchedule.find({sdate:{$in:d}}).sort({idb:1,odr:1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  get_query_monthschedule(d){
    return new Promise((resolve, reject) => {
      db.DaySchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.DaySchedule.find({}).sort({idb:1,odr:1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  get_query_monthschedule2(sdate,ide){
    return new Promise((resolve, reject) => {
      db.DaySchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.DaySchedule.find({ide:ide,sdate:{$gte:sdate}}).sort({sdate:1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  remake_belongs(datalist){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Belong.loadDatabase((err)=>{
        if(err) reject(err)
        db.Belong.remove({}, { multi: true }, function(err, numRemoved){
          if(err) reject(err)
        })
        db.Belong.insert(datalist,(err,newdoc)=>{
          if(err) reject(err)
          resolve(newdoc)
        })
      })
    })
  }
  update_employee(ide,changed){
    return new Promise((resolve, reject) => {
      db.Employee.loadDatabase((err)=>{
        if(err) reject(err)
        db.Employee.update({ide:ide},{$set:changed},{upsert:true},(err,rows,upsert)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  delete_employee(ide){
    return new Promise((resolve, reject) => {
      db.Employee.loadDatabase((err)=>{
        if(err) reject(err)
        db.Employee.remove({ide:ide},{},(err,rows)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  update_monthschedule(sdate,ide,changed){
    return new Promise((resolve, reject) => {
      db.DaySchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.DaySchedule.update({ide:ide,sdate:{$gte:sdate}},{$set:changed},{multi:true},(err,rows,upsert)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  delete_monthschedule(sdate,ide){
    return new Promise((resolve, reject) => {
      db.DaySchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.DaySchedule.remove({ide:ide,sdate:{$gte:sdate}},{multi:true},(err,rows)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }


  new_holidays(daylist){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Holiday.loadDatabase((err)=>{
        if(err) reject(err)
        let datalist = []
        for(var i=0;i<daylist.length;i++){
          datalist[i] = {day:daylist[i]}
        }
        db.Holiday.insert(datalist,(err,rows)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  delete_holidays(daylist){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Holiday.loadDatabase((err)=>{
        if(err) reject(err)
        let datalist = []
        for(var i=0;i<daylist.length;i++){
          datalist[i] = {day:daylist[i]}
          db.Holiday.remove(datalist[i],{multi:true},(err,rows)=>{
            if(err) reject(err)
          })
        }
        resolve()
      })
    })
  }
  get_query_holiday(sdate,fdate){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Holiday.loadDatabase((err)=>{
        if(err) reject(err)
        db.Holiday.find({day:{$lte:fdate,$gte:sdate}},(err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }

  dammydata_holiday(){
    return new Promise((resolve,reject) => {
      let db = this.conn()
      db.Holiday.loadDatabase((err) => {
        const datalist1 = [
          {day:'2021-01-01'},
          {day:'2021-01-02'},
          {day:'2021-01-03'},
        ]
        db.Holiday.insert(datalist1,(err,res)=>{
          if(err) reject(err)
          resolve(res)
        })
      })
    })
  }
}
module.exports = Nedb
