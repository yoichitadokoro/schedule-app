const Datastore = require('nedb')
let db = {}
const fname = {
  BlowMachine:'db/BlowMachine.json',
  BlowSchedule:'db/BlowSchedule.json',
  InjMachine:'db/InjMachine.json',
  InjSchedule:'db/InjSchedule.json',
  Holiday:'db/Holiday.json',
  Belong:'db/Belong.json',
  Employee:'db/Employee.json',
  Lunch:'db/Lunch.json',
  Bugs:'db/Bugs.json',
}

class Nedb{
  conn () {
    if (!db || !db.open) {
      db.BlowMachine = new Datastore({filename:fname.BlowMachine})
      db.BlowSchedule = new Datastore({filename:fname.BlowSchedule})
      db.InjMachine = new Datastore({filename:fname.InjMachine})
      db.InjSchedule = new Datastore({filename:fname.InjSchedule})
      db.Holiday = new Datastore({filename:fname.Holiday})
      db.Belong = new Datastore({filename:fname.Belong})
      db.Employee = new Datastore({filename:fname.Employee})
      db.Lunch = new Datastore({filename:fname.Lunch})
      db.Bugs = new Datastore({filename:fname.Bugs})
    }
    return db
  }
  conn2(dbfile){
    const fn = "db/data/" + dbfile + ".json"
    db.DaySchedule = new Datastore({filename:fn})
    return db
  }
  createBlowtable(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.BlowMachine.loadDatabase((err)=>{
        if(err) reject(err)
        db.BlowMachine.find({},(err,docs)=>{
          if(err) reject(err)
          if(docs.length == 0){
            const datalist = [
                {idm:1, fullname:'1GT2号機',dispname:'2号',odr:1,jusigata:true},
                {idm:2, fullname:'1GT3号機',dispname:'3号',odr:2,jusigata:false},
                {idm:3, fullname:'1GT4号機',dispname:'4号',odr:3,jusigata:true},
                {idm:4, fullname:'PEM',dispname:'PEM',odr:4,jusigata:false},
                {idm:5, fullname:'TSD-1L',dispname:'TSD',odr:5,jusigata:false},
                {idm:6, fullname:'Sidel Matrix',dispname:'Sidel',odr:6,jusigata:false},
            ]
            db.BlowMachine.insert(datalist,(err,newdoc)=>{
              if(err) reject(err)
              resolve(newdoc)
            })
          }else{
            console.log(docs)
            resolve(docs)
          }
        })
      })
    })
  }
  createInjtable(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.InjMachine.loadDatabase((err)=>{
        if(err) reject(err)
        db.InjMachine.find({},(err,docs)=>{
          if(err) reject(err)
          if(docs.length == 0){
            const datalist = [
                  {idm:1, fullname:'NEX110',dispname:'NEX110',odr:1},
                  {idm:2, fullname:'NEX2000',dispname:'NEX2000',odr:2},
                  {idm:3, fullname:'ES3000',dispname:'ES3000',odr:3},
                  {idm:4, fullname:'NEX140',dispname:'NEX140',odr:4},
                  {idm:5, fullname:'結晶化HT1',dispname:'HT1',odr:5},
                  {idm:6, fullname:'結晶化HT2',dispname:'HT2',odr:6},
                  {idm:7, fullname:'二色成形機',dispname:'二色',odr:7},
            ]
            db.InjMachine.insert(datalist,(err,newdoc)=>{
              if(err) reject(err)
              resolve(newdoc)
            })
          }else{
            console.log(docs)
            resolve(docs)
          }
        })
      })
    })
  }
  createBelongtable(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Belong.loadDatabase((err)=>{
        if(err) reject(err)
        db.Belong.find({},(err,docs)=>{
          if(err) reject(err)
          if(docs.length == 0){
            const datalist = [
                {idb:1, name:'所長・部長'},
                {idb:2, name:'機能材料研究室'},
                {idb:3, name:'包装材料研究室'},
                {idb:4, name:'生物化学研究室'},
                {idb:5, name:'分析化学研究室'},
                {idb:6, name:'成形加工研究室'},
                {idb:7, name:'情報数理研究室'},
                {idb:8, name:'調査企画室'},
                {idb:9, name:'特許室'},
                {idb:10, name:'事務室'},
                {idb:11, name:'その他'},
            ]
            db.Belong.insert(datalist,(err,newdoc)=>{
              if(err) reject(err)
              resolve(newdoc)
            })
          }else{
            console.log(docs)
            resolve(docs)
          }
        })
      })
    })
  }
  createLunchtable(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Lunch.loadDatabase((err)=>{
        if(err) reject(err)
        db.Lunch.find({},(err,docs)=>{
          if(err) reject(err)
          if(docs.length == 0){
            const datalist = [
                {sdate:"2021-08-03",addlunch:3,detlunch:70},
                {sdate:"2021-08-04",addlunch:2,detlunch:67},
            ]
            db.Lunch.insert(datalist,(err,newdoc)=>{
              if(err) reject(err)
              resolve(newdoc)
            })
          }else{
            console.log(docs)
            resolve(docs)
          }
        })
      })
    })
  }

  get_query_belongs(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Belong.loadDatabase((err)=>{
        if(err) reject(err)
        db.Belong.find({}).sort({idb:1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  get_query_employees(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Employee.loadDatabase((err)=>{
        if(err) reject(err)
        db.Employee.find({}).sort({odr:1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  get_query_dayschedule(d){
    return new Promise((resolve, reject) => {
      db.DaySchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.DaySchedule.find({sdate:d}).sort({odr:1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  update_dayschedule(name,sdate,changed){
    return new Promise((resolve, reject) => {
      db.DaySchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.DaySchedule.update({name:name,sdate:sdate},{$set:changed},{upsert:true},(err,rows,upsert)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  delete_dayschedule(name,sdate){
    return new Promise((resolve, reject) => {
      db.DaySchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.DaySchedule.remove({name:name,sdate:sdate},{},(err,rows)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  get_query_lunch(d){
    return new Promise((resolve, reject) => {
      db.Lunch.loadDatabase((err)=>{
        if(err) reject(err)
        db.Lunch.findOne({sdate:d}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  update_lunch(datalist){
    return new Promise((resolve, reject) => {
      db.Lunch.loadDatabase((err)=>{
        if(err) reject(err)
        db.Lunch.update({sdate:datalist.sdate},{$set:datalist},{upsert:true},(err,rows,upsert)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  new_bugs(datalist){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Bugs.loadDatabase((err)=>{
        if(err) reject(err)
        db.Bugs.insert(datalist,(err,rows)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  get_query_allholiday(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Holiday.loadDatabase((err)=>{
        if(err) reject(err)
        db.Holiday.find({},(err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  get_query_weekschedule(d){
    return new Promise((resolve, reject) => {
      db.DaySchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.DaySchedule.find({sdate:{$in:d}}).sort({idb:1,odr:1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }

  get_query_blow_machines(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.BlowMachine.loadDatabase((err)=>{
        if(err) reject(err)
        db.BlowMachine.find({}).sort({odr:1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  get_query_blow_schedule(sdate,fdate){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.BlowSchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.BlowSchedule.find({start_date:{$lte:fdate},end_date:{$gte:sdate}}).sort({blow_machine:1,start_date:1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  get_query_blow_schedule2(sdate,fdate,machine){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.BlowSchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.BlowSchedule.find({blow_machine:machine,start_date:{$lte:fdate},end_date:{$gte:sdate}}).sort({blow_machine:1,start_date:1}).exec((err,rows)=>{
          if (err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  get_query_inj_machines(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.InjMachine.loadDatabase((err)=>{
        if(err) reject(err)
        db.InjMachine.find({}).sort({odr:1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  get_query_inj_schedule(sdate,fdate){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.InjSchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.InjSchedule.find({start_date:{$lte:fdate},end_date:{$gte:sdate}}).sort({start_date:1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  get_query_inj_schedule2(sdate,fdate,machine){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.InjSchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.InjSchedule.find({inj_machine:machine,start_date:{$lte:fdate},end_date:{$gte:sdate}}).sort({inj_machine:1,start_date:1}).exec((err,rows)=>{
          if (err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  get_query_holiday(sdate,fdate){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Holiday.loadDatabase((err)=>{
        if(err) reject(err)
        db.Holiday.find({day:{$lte:fdate,$gte:sdate}},(err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  get_query_blow_jusigata(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.BlowMachine.loadDatabase((err)=>{
        if(err) reject(err)
        db.BlowMachine.find({jusigata:true}).sort({odr:1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs)
        })
      })
    })
  }
  new_blow_schedule(data,idmax){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.BlowSchedule.loadDatabase((err)=>{
        if(err) reject(err)
        const datalist = {
          id:idmax+1,
          blow_machine:data[0],
          name:data[1],
          summary:data[2],
          PFgeom:data[3],
          PFnum:data[4],
          start_date:data[5],
          end_date:data[6],
          plamold:data[7],
          plantPF:data[8],
          color:data[9],
          iserr:data[10],
          created_at:data[11],
        }
        db.BlowSchedule.insert(datalist,(err,rows)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  new_inj_schedule(data,idmax){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.InjSchedule.loadDatabase((err)=>{
        if(err) reject(err)
        const datalist = {
          id:idmax+1,
          inj_machine:data[0],
          name:data[1],
          summary:data[2],
          start_date:data[3],
          end_date:data[4],
          color:data[5],
          iserr:data[6],
          created_at:data[7],
        }
        db.InjSchedule.insert(datalist,(err,rows)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  update_blow_schedule(data){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.BlowSchedule.loadDatabase((err)=>{
        if(err) reject(err)
        const datalist = {
          id:data[0],
          blow_machine:data[1],
          name:data[2],
          summary:data[3],
          PFgeom:data[4],
          PFnum:data[5],
          start_date:data[6],
          end_date:data[7],
          plamold:data[8],
          plantPF:data[9],
          color:data[10],
          iserr:data[11],
          created_at:data[12],
        }
        db.BlowSchedule.update({id:data[0]},datalist,{},(err,rows)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  update_inj_schedule(data){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.InjSchedule.loadDatabase((err)=>{
        if(err) reject(err)
        const datalist = {
          id:data[0],
          inj_machine:data[1],
          name:data[2],
          summary:data[3],
          start_date:data[4],
          end_date:data[5],
          color:data[6],
          iserr:data[7],
          created_at:data[8],
        }
        db.InjSchedule.update({id:data[0]},datalist,{},(err,rows)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  delete_blow_schedule(id1){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.BlowSchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.BlowSchedule.remove({id:id1},(err,res)=>{
          if(err) reject(err)
          resolve(res)
        })
      })
    })
  }
  delete_inj_schedule(id1){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.InjSchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.InjSchedule.remove({id:id1},(err,res)=>{
          if(err) reject(err)
          resolve(res)
        })
      })
    })
  }
  get_query_idmax_blow(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.BlowSchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.BlowSchedule.findOne({}).sort({id:-1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs.id)
        })
      })
    })
  }
  get_query_idmax_inj(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.InjSchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.InjSchedule.findOne({}).sort({id:-1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs.id)
        })
      })
    })
  }
  clean_old(){
    return new Promise(async(resolve, reject) => {
      let db = this.conn()
      const date = new Date()
      let cnt = 0
      const old = (date.getFullYear()-2) + "-" + ('0' + (date.getMonth() + 1)).slice(-2) + "-" + ('0' + date.getDate()).slice(-2)
      const cnt_b = await this.clean_old_blow(old)
      const cnt_i = await this.clean_old_inj(old)
      cnt = cnt_b + cnt_i
      resolve(cnt)
    })
  }
  clean_old_blow(old){
    return new Promise((resolve,reject)=>{
      let db = this.conn()
      db.BlowSchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.BlowSchedule.remove({end_date:{$lte:old}},(err,res)=>{
          if(err) reject(err)
          resolve(res)
        })
      })
    })
  }
  clean_old_inj(old){
    return new Promise((resolve,reject)=>{
      let db = this.conn()
      db.InjSchedule.loadDatabase((err)=>{
        if(err) reject(err)
        db.InjSchedule.remove({end_date:{$lte:old}},(err,res)=>{
          if(err) reject(err)
          resolve(res)
        })
      })
    })
  }
  get_query_idm_blowm(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.BlowMachine.loadDatabase((err)=>{
        if(err) reject(err)
        db.BlowMachine.findOne({}).sort({idm:-1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs.idm)
        })
      })
    })
  }
  get_query_idm_injm(){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.InjMachine.loadDatabase((err)=>{
        if(err) reject(err)
        db.InjMachine.findOne({}).sort({idm:-1}).exec((err,docs)=>{
          if(err) reject(err)
          resolve(docs.idm)
        })
      })
    })
  }
  update_blow_machine(data){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.BlowMachine.loadDatabase((err)=>{
        if(err) reject(err)
        const datalist = {
          idm:data[0],
          fullname:data[1],
          dispname:data[2],
          odr:data[3],
          jusigata:data[4],
        }
        db.BlowMachine.update({idm:data[0]},datalist,{},(err,rows)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  update_inj_machine(data){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.InjMachine.loadDatabase((err)=>{
        if(err) reject(err)
        const datalist = {
          idm:data[0],
          fullname:data[1],
          dispname:data[2],
          odr:data[3],
        }
        db.InjMachine.update({idm:data[0]},datalist,{},(err,rows)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  delete_blow_machine(id1){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.BlowMachine.loadDatabase((err)=>{
        if(err) reject(err)
        db.BlowMachine.remove({idm:id1},(err,res)=>{
          if(err) reject(err)
          resolve(res)
        })
      })
    })
  }
  delete_inj_machine(id1){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.InjMachine.loadDatabase((err)=>{
        if(err) reject(err)
        db.InjMachine.remove({idm:id1},(err,res)=>{
          if(err) reject(err)
          resolve(res)
        })
      })
    })
  }
  new_blow_machine(data,idmax){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.BlowMachine.loadDatabase((err)=>{
        if(err) reject(err)
        const datalist = {
          idm:idmax+1,
          fullname:data[0],
          dispname:data[1],
          odr:data[2],
          jusigata:data[3],
        }
        db.BlowMachine.insert(datalist,(err,rows)=>{
          if(err) reject(err)
          resolve(rows)
        })
      })
    })
  }
  new_inj_machine(data,idmax){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.InjMachine.loadDatabase((err)=>{
        if(err) reject(err)
        const datalist = {
          idm:idmax+1,
          fullname:data[0],
          dispname:data[1],
          odr:data[2],
        }
        db.InjMachine.insert(datalist,(err,rows)=>{
          if(err) reject(err)
          resolve(rows)
        })
      })
    })
  }
  new_holidays(daylist){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Holiday.loadDatabase((err)=>{
        if(err) reject(err)
        let datalist = []
        for(var i=0;i<daylist.length;i++){
          datalist[i] = {day:daylist[i]}
        }
        db.Holiday.insert(datalist,(err,rows)=>{
          if(err) reject(err)
          resolve(rows || [])
        })
      })
    })
  }
  delete_holidays(daylist){
    return new Promise((resolve, reject) => {
      let db = this.conn()
      db.Holiday.loadDatabase((err)=>{
        if(err) reject(err)
        let datalist = []
        for(var i=0;i<daylist.length;i++){
          datalist[i] = {day:daylist[i]}
          db.Holiday.remove(datalist[i],{multi:true},(err,rows)=>{
            if(err) reject(err)
          })
        }
        resolve()
      })
    })
  }

  dammydata_blow(){
    return new Promise((resolve,reject) => {
      let db = this.conn()
      db.BlowSchedule.loadDatabase((err) => {
        const date = new Date()
        const now = date.toString()
        const datalist1 = [
            {id:1, blow_machine:1,name:'鈴木',summary:'ブロー１',PFgeom:1,PFnum:100,start_date:'2021-01-01',end_date:'2021-01-05',plamold:false,plantPF:'Y',color:'#ffff00',created_at:now,iserr:0},
            {id:2, blow_machine:1,name:'佐藤',summary:'ブロー２',PFgeom:1,PFnum:200,start_date:'2021-01-20',end_date:'2021-01-29',plamold:false,plantPF:'Y',color:'#ff0000',created_at:now,iserr:0},
            {id:3, blow_machine:3,name:'山田',summary:'ブロー３',PFgeom:2,PFnum:500,start_date:'2021-01-01',end_date:'2021-01-05',plamold:false,plantPF:'Y',color:'#00ff00',created_at:now,iserr:0},
            {id:4, blow_machine:4,name:'高橋',summary:'ブロー４',PFgeom:1,PFnum:500,start_date:'2021-01-01',end_date:'2021-01-05',plamold:false,plantPF:'Y',color:'#fffff0',created_at:now,iserr:0},
            {id:5, blow_machine:4,name:'渡邊',summary:'ブロー５',PFgeom:1,PFnum:500,start_date:'2021-01-01',end_date:'2021-01-05',plamold:false,plantPF:'Y',color:'#0f0f00',created_at:now,iserr:0},
            {id:6, blow_machine:4,name:'菅',summary:'ブロー６',PFgeom:1,PFnum:500,start_date:'2021-01-06',end_date:'2021-01-10',plamold:false,plantPF:'Y',color:'#ffff00',created_at:now,iserr:0},
        ]
        db.BlowSchedule.insert(datalist1,(err,res)=>{
          if(err) reject(err)
          resolve(res)
        })
      })
    })
  }
  dammydata_inj(){
    return new Promise((resolve,reject) => {
      let db = this.conn()
      db.InjSchedule.loadDatabase((err) => {
        const date = new Date()
        const now = date.toString()
        const datalist1 = [
            {id:1, inj_machine:1,name:'鈴木',summary:'テスト１',start_date:'2021-01-01',end_date:'2021-01-05',color:'#ffff00',created_at:now,iserr:0},
            {id:2, inj_machine:1,name:'佐藤',summary:'テスト２',start_date:'2021-01-20',end_date:'2021-01-29',color:'#ff0000',created_at:now,iserr:0},
            {id:3, inj_machine:2,name:'山田',summary:'テスト３',start_date:'2021-01-01',end_date:'2021-01-05',color:'#00ff00',created_at:now,iserr:0},
            {id:4, inj_machine:3,name:'高橋',summary:'テスト４',start_date:'2021-01-01',end_date:'2021-01-05',color:'#fffff0',created_at:now,iserr:0},
            {id:5, inj_machine:4,name:'渡邊',summary:'テスト５',start_date:'2021-01-01',end_date:'2021-01-05',color:'#0f0f00',created_at:now,iserr:0},
            {id:6, inj_machine:5,name:'菅',summary:'テスト６',start_date:'2021-01-06',end_date:'2021-01-10',color:'#ffff00',created_at:now,iserr:0},
        ]
        db.InjSchedule.insert(datalist1,(err,res)=>{
          if(err) reject(err)
          resolve(res)
        })
      })
    })
  }
  dammydata_holiday(){
    return new Promise((resolve,reject) => {
      let db = this.conn()
      db.Holiday.loadDatabase((err) => {
        const datalist1 = [
          {day:'2021-01-01'},
          {day:'2021-01-02'},
          {day:'2021-01-03'},
        ]
        db.Holiday.insert(datalist1,(err,res)=>{
          if(err) reject(err)
          resolve(res)
        })
      })
    })
  }
}
module.exports = Nedb
