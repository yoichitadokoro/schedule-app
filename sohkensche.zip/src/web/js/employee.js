const {ipcRenderer,shell} = require('electron')

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})

async function tohome(){
  await ipcRenderer.invoke("toHome")
}

// 利用方法
async function howto(){
  shell.openItem(process.cwd()+"\\manual.pdf")
  //alert(process.cwd()+"\\manual.pdf")
}
// 不具合報告
$('#button_bugsend').on("click",async function(){
  const str1 = $('textarea[name="bugtxt"]').val();
  await ipcRenderer.invoke("BugSend",{txt:str1.replace(/\r?\n/g, '<br>')})
  .then((res)=>{
    //alert(res)
  })
  .catch((err) => {
    alert(err)
  })
  $('textarea[name="bugtxt"]').val("")
})

var maincontent = new Vue({
  el: '#maincontent',
  async mounted(){
    await ipcRenderer.invoke("GetBelong")
    .then((res)=>{
      this.belong = res
      this.idbmax = Math.max(...res.map((p)=> p.idb))
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("GetEmployee")
    .then((res)=>{
      this.employee = res
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("getTodayVue")
    .then((res)=>{
      this.today = res
      this.dayset = res
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("EmployeeExist")
    .then((res)=>{
      this.existsub = res
    })
    .catch((err)=>{
      alert(err)
    })
    $('[data-toggle="tooltip"]').tooltip()
  },
  data: {
    belong:[],
    today:'',
    curday:'',
    inpday:'',
    bugtxt:'',
    isedit:false,
    edm:-1,
    edmemo:-1,
    edlunch:-1,
    edkubun:-1,
    eddest:-1,
    edperiod:-1,
    edsign1:-1,
    edsignd1:-1,
    edsign2:-1,
    edsignd2:-1,
    edremark:-1,
    employee:[],
    lunchdata:[],
    lchange:false,
    test:'test',
    addvisit:false,
    visitor:{"belong":"","name":"","tel":"","memo":"","alunch":"","slunch":"○","kubun":"","dest":"","period":"","sign1":"","signd1":"","sign2":"","signd2":"","remark":""},
    sche:[],
    lunchplus:0,
    detlunch:0,
    eddetlunch:false,
    holiday:[],
    bselect:0,
    res:0,
    idbmax:0,
    changedata:[],
    deldata:[],
    dayset:'',
    existsub:false,
    iskubun:[],
    beforekubun:false,
    islunch:[],
    beforelunch:false,
  },
  methods:{
    date_to_ja(str){
       s = str.split("-")
       return s[0]+"年"+(s[1]*1)+"月"+(s[2]*1)+"日("+ this.weekday_str(str) + ")"
    },
    date_to_str(date){
       return date.getFullYear() + "-" + ('0' + (date.getMonth() + 1)).slice(-2) + "-" + ('0' + date.getDate()).slice(-2)
    },
    date_to_sign(str){
      if(str != ""){
        s = str.split("-")
        return (s[1]*1)+"/"+(s[2]*1)
      }else{
        return ""
      }
    },
    weekday_str(str){
       return '日月火水木金土'[new Date(str).getDay()];
    },
    maru_to_bool(b){
      if(b == "○") return true
      else return false
    },
    bool_to_maru(b){
      if(b) return "○"
      else return "×"
    },
    ishol(){
      const curd = new Date(this.curday)
      let curh = this.holiday.filter(items => items.day == this.curday)
      if(curd.getDay() == 0 || curd.getDay() == 6 || curh.length > 0) return true
      else return false
    },
    countlunch_maru(){
      const fil = this.sche.filter(function(s){
        return s.alunch == "○"
      })
      return fil.length
    },
    countlunch_badtz(){
      const fil = this.sche.filter(function(s){
        return s.alunch == "×"
      })
      return fil.length
    },
    countlunch_sum(){
      return parseInt(this.countlunch_maru()) + parseInt(this.lunchplus)
    },
    count_kubun(txt){
      const fil = this.sche.filter(function(s){
        return s.kubun == txt
      })
      return fil.length
    },
    count_kubun2(txt,idb){
      const fil = this.sche.filter(function(s){
        return s.kubun == txt && s.idb == (idb+1)
      })
      return fil.length
    },
    resetvisitor(){
      this.visitor = {"belong":"","name":"","tel":"","memo":"","alunch":"","slunch":"○","kubun":"","dest":"","period":"","sign1":"","signd1":"","sign2":"","signd2":"","remark":""}
    },
    async delsche(delid){
      await ipcRenderer.invoke("DeleteSchedule",{sdate:this.curday,name:this.sche[delid].name})
      .then((res)=>{
        this.sche.splice(delid,1)
      })
      .catch((err)=>{
        alert(err)
      })
    },
    daycolor(){
      wk = new Date(this.curday).getDay()
      if(wk == 0) return "red"
      else if(wk == 6) return "blue"
      else if(this.ishol()) return "red"
      else return "black"
    },
    sche_div(idb){
      let ds = this.sche.filter(items => items.idb == (idb+1))
      return ds
    },
    opentable(idb){
      $('#collapseTable'+idb).collapse('show')
    },
    bopen(idb){
      if(this.bselect == idb) return "collapse show"
      else return "collapse"
    },
    async sendbelong(idb){
      await ipcRenderer.invoke("SendSelectedBelong",idb)
      .then((res)=>{
        this.bselect = res
        setTimeout(function(){
          window.location.href = "#belong"+res
        },100)
      })
      .catch((err)=>{
        alert(err)
      })
    },
    idbchange: function(event,edid){
      if(event){
        let idbn = this.belong.filter(items => items.idb == event.target.value)
        this.employee[edid].idb = event.target.value
        this.employee[edid].belong = idbn[0].name
        let idbfil = this.employee.filter(items => items.idb == event.target.value)
        let idbmax = idbfil.reduce((a,b)=>a.odr>b.odr?a:b).odr
        this.employee[edid].odr = idbmax + 1
      }
    },
    idbchange_new: function(event){
      if(event){
        this.visitor.idb = event.target.value
        this.visitor.belong = this.belong[this.visitor.idb-1].name
      }
    },
    resortemp(){
      this.employee = [...this.employee].sort((a, b) => a.odr - b.odr)
      this.changedata = this.changedata.filter((item, index, self) => {
        // name だけをリスト化する
        const nameList = self.map(item => item['ide']);
        // 重複を削除する
        if (nameList.indexOf(item.ide) === index) {
          return item;
        }
      });
    },
    resetodr(){
      let lb = Array(this.belong.length)
      lb.fill(0)
      for(var i=0;i<this.employee.length;i++){
        const j = this.employee[i].idb
        lb[j]++
        let odrstr = ('00' + j).slice(-2) + ('000' + lb[j]).slice(-3)
        this.employee[i].odr = parseInt(odrstr)
      }
    },
    changefin(){
      this.changedata.push(this.employee[this.edm])
      this.iskubun.push(this.beforekubun)
      this.islunch.push(this.beforelunch)
      this.resortemp()
      this.edm = -1
      this.beforekubun = false
      this.beforelunch = false
    },
    adddel(edid){
      this.deldata.push(this.employee[edid])
      this.employee.splice(edid,1)
    },
    newmember(){
      if(this.visitor.name!="" && this.visitor.idb!=null){
        let odrs = this.employee.filter(items => items.idb == this.visitor.idb)
        this.visitor.odr = Math.max(...odrs.map((p)=> p.odr)) + 1
        this.visitor.ide = Math.max(...this.employee.map((p) => p.ide)) + 1
        this.changedata.push(this.visitor)
        this.iskubun.push(true)
        this.islunch.push(true)
        this.employee.push(this.visitor)
        this.resortemp()
        this.resetvisitor()
        alert("追加しました")
      }else{
        alert("入力に不備があります")
      }
    },
    upodr(edid){
      if(edid==0) return
      else if(this.employee[edid].idb != this.employee[edid-1].idb){
        alert("所属を越えての移動はできません")
        return
      }else{
        const otmp = this.employee[edid].odr
        this.employee[edid].odr = this.employee[edid-1].odr
        this.employee[edid-1].odr = otmp
        this.changedata.push(this.employee[edid])
        this.changedata.push(this.employee[edid-1])
        this.resortemp()
      }
    },
    downodr(edid){
      if(edid==this.employee.length-1) return
      else if(this.employee[edid].idb != this.employee[edid+1].idb){
        alert("所属を越えての移動はできません")
        return
      }else{
        const otmp = this.employee[edid].odr
        this.employee[edid].odr = this.employee[edid+1].odr
        this.employee[edid+1].odr = otmp
        this.changedata.push(this.employee[edid])
        this.changedata.push(this.employee[edid+1])
        this.resortemp()
      }
    },
    async setemployee(){
      if(this.edm!=-1){
        alert("編集中の項目があります。完了ボタンを押してください")
        return
      }
      if(this.existsub && this.dayset > this.today){
        if(!confirm("既に予約データが存在しますがよろしいですか？")) return
      }
      if(this.changedata.length > 0 || this.deldata.length > 0){
        await ipcRenderer.invoke("SetEmployee",{changedata:this.changedata,deldata:this.deldata,dayset:this.dayset,iskubun:this.iskubun,islunch:this.islunch})
        .then((res)=>{
          alert("送信しました("+this.dayset+")から変更")
          window.location.href = "staff.html"
        })
        .catch((err)=>{
          alert(err)
        })
      }else{
          window.location.href = "staff.html"
      }
    },
    kubunchange_e(event,edid){
      if(event){
        this.beforekubun = true
        this.employee[edid].kubun = event.target.value
      }
    },
    lunchchange_e(event,edid){
      if(event){
        this.beforelunch = true
        this.employee[edid].alunch = event.target.value
      }
    },
  }
})
