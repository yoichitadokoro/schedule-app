const {ipcRenderer} = require('electron')
// ホーム
async function button_home(){
//      let val = await eel.PostDateNavi('',0)()
  let val = await ipcRenderer.invoke("PostDateNavi",{date:"",tabs:0})
}
// 予定印刷
async function printPDF(){
//      let val = await eel.GetPDF()((res) => {
  let val = await ipcRenderer.invoke("GetPDF")
  .then((res)=>{
    const fn = function(){
      window.open(res,'_blank','scrollbars=1,location=0,menubar=0,toolbar=0,status=1,directories=0,resizable=1')
    }
    setTimeout(fn,100)
  })
  .catch((err)=>{
    alert(err)
  })
}
// 利用方法
$('#howto').on("click",async function(){
  shell.openItem(process.cwd()+"\\manual.pdf")
})
// 子ウインドウからの更新処理
window.addEventListener('message', (e) => {
  window.location.reload()
})


var blow_machine = new Vue({
  el: '#blowmachine',
  async mounted(){
//    await eel.GetBlowMachine()((res) => {
    await ipcRenderer.invoke("GetBlowMachine")
    .then((res)=>{
      this.blowmachine = res
    })
    .catch((err)=>{
      alert(err)
    })
  },
  data: {
    blowmachine:[],
    id1:0,
    fullname:'',
    dispname:'',
    odr:0,
    jusigata:0,
    res:0
  },
  methods: {
    maru(b){
      if(b) return '○'
      else return ' '
    },
    edit_button(e){
      const m = this.blowmachine[e]
      this.id1 = m['idm']
      this.fullname = m['fullname']
      this.dispname = m['dispname']
      this.odr = m['odr']
      this.jusigata = m['jusigata']
    },
    async dchange(){
      datalist = [this.id1,this.fullname,this.dispname,this.odr,this.jusigata]
//      await eel.SetEditBlowMachine(datalist)((res) => {
      await ipcRenderer.invoke("SetEditBlowMachine",datalist)
      .then((res)=>{
        this.res = res
        alert("変更しました")
      })
      .catch((err)=>{
        alert("失敗しました"+err)
      })
//      await eel.GetBlowMachine()((res) => {
      await ipcRenderer.invoke("GetBlowMachine")
      .then((res)=>{
        this.blowmachine = res
      })
      .catch((err)=>{
        alert(err)
      })
    },
    async del(e){
      if(window.confirm('削除してよろしいですか？')){
//          await eel.DeleteBlowMachine(e)((res) => {
          await ipcRenderer.invoke("DeleteBlowMachine",e)
          .then((res)=>{
            if(res == 1){
              this.res = res
              alert("削除しました")
            }
          })
          .catch((err)=>{
            alert("失敗しました")
          })
//          await eel.GetBlowMachine()((res) => {
          await ipcRenderer.invoke("GetBlowMachine")
          .then((res)=>{
            this.blowmachine = res
          })
          .catch((err)=>{
            alert(err)
          })
      }
    },
    add_button(){
      const m = this.blowmachine.slice(-1)[0]
      this.fullname = ''
      this.dispname = ''
      this.odr = m['odr'] + 1
      this.jusigata = 0
    },
    async add(){
      datalist = [this.fullname,this.dispname,this.odr,this.jusigata]
//      await eel.NewBlowMachine(datalist)((res) =>{
      await ipcRenderer.invoke("NewBlowMachine",datalist)
      .then((res)=>{
        this.res = res
        alert("追加しました")
      })
      .catch((err)=>{
        alert(err)
      })
//      await eel.GetBlowMachine()((res) => {
      await ipcRenderer.invoke("GetBlowMachine")
      .then((res)=>{
        this.blowmachine = res
      })
      .catch((err)=>{
        alert(err)
      })
    },
  }
})
var inj_machine = new Vue({
  el: '#injmachine',
  async mounted(){
//    await eel.GetInjMachine()((res) => {
    await ipcRenderer.invoke("GetInjMachine")
    .then((res)=>{
      this.injmachine = res
    })
    .catch((err)=>{
      alert(err)
    })
  },
  data: {
    injmachine:[],
    id1:0,
    fullname:'',
    dispname:'',
    odr:0,
    res:0
  },
  methods: {
    edit_button(e){
      m = this.injmachine[e]
      this.id1 = m['idm']
      this.fullname = m['fullname']
      this.dispname = m['dispname']
      this.odr = m['odr']
    },
    async dchange(){
      datalist = [this.id1,this.fullname,this.dispname,this.odr]
//      await eel.SetEditInjMachine(datalist)((res) => {
      await ipcRenderer.invoke("SetEditInjMachine",datalist)
      .then((res)=>{
        this.res = res
        alert("変更しました")
      })
      .catch((err)=>{
        alert(err)
      })
//      await eel.GetInjMachine()((res) => {
      await ipcRenderer.invoke("GetInjMachine")
      .then((res)=>{
        this.injmachine = res
      })
      .catch((err)=>{
        alert(err)
      })
    },
    async del(e){
      if(window.confirm('削除してよろしいですか？')){
//          await eel.DeleteInjMachine(e)((res) => {
          await ipcRenderer.invoke("DeleteInjMachine",e)
          .then((res)=>{
            if(res == 1){
              this.res = res
              alert("削除しました")
            }
          })
          .catch((err)=>{
            alert("失敗しました"+err)
          })
//          await eel.GetInjMachine()((res) => {
          await ipcRenderer.invoke("GetInjMachine")
          .then((res)=>{
            this.injmachine = res
          })
          .catch((err)=>{
            alert(err)
          })
      }
    },
    add_button(){
      const m = this.injmachine.slice(-1)[0]
      this.fullname = ''
      this.dispname = ''
      this.odr = m['odr'] + 1
      this.jusigata = 0
    },
    async add(){
      datalist = [this.fullname,this.dispname,this.odr]
//      await eel.NewInjMachine(datalist)((res) =>{
      await ipcRenderer.invoke("NewInjMachine",datalist)
      .then((res)=>{
        this.res = res
        alert("追加しました")
      })
      .catch((err)=>{
        alert(err)
      })
//      await eel.GetInjMachine()((res) => {
      await ipcRenderer.invoke("GetInjMachine")
      .then((res)=>{
        this.injmachine = res
      })
      .catch((err)=>{
        alert(err)
      })
    },
  }
})
