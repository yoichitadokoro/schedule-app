const {ipcRenderer,shell} = require('electron')

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})

async function tohome(){
  await ipcRenderer.invoke("toHome")
}

// 利用方法
async function howto(){
  shell.openItem(process.cwd()+"\\manual.pdf")
  //alert(process.cwd()+"\\manual.pdf")
}
// 不具合報告
$('#button_bugsend').on("click",async function(){
  const str1 = $('textarea[name="bugtxt"]').val();
  await ipcRenderer.invoke("BugSend",{txt:str1.replace(/\r?\n/g, '<br>')})
  .then((res)=>{
    //alert(res)
  })
  .catch((err) => {
    alert(err)
  })
  $('textarea[name="bugtxt"]').val("")
})

var maincontent = new Vue({
  el: '#maincontent',
  async mounted(){
    await ipcRenderer.invoke("GetBelong")
    .then((res)=>{
      this.belong = res
      this.idbmax = Math.max(...res.map((p)=> p.idb))
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("GetEmployee")
    .then((res)=>{
      this.employee = res
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("GetDaySchedule")
    .then((res)=>{
      this.sche = res
      if(res.length > 0){
        //this.lodr = Array(1+Math.max(...res.map((p) => p.ide)))
        this.lodr = Array(2000)
        this.lodr.fill(-1)
        for(var i=0;i<res.length;i++){
          this.lodr[res[i].ide] = i
        }
      }
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("GetLunch",{curday:''})
    .then((res)=>{
      this.lunchplus = res.addlunch
      this.detlunch = res.detlunch
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("getTodayVue")
    .then((res)=>{
      this.today = res
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("getCurday")
    .then((res)=>{
      this.curday = res
      this.inpday = res
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("GetHoliday")
    .then((res)=>{
      this.holiday = res
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("GetSelectedBelong")
    .then((res)=>{
      this.bselect = res
      if(res != -1 && !this.ishol()){
        setTimeout(function(){
          window.location.href = "#belong"+res
        },100)
      }
    })
    .catch((err)=>{
        alert(err)
    })
    $('[data-toggle="tooltip"]').tooltip()
  },
  data: {
    belong:[],
    today:'',
    curday:'',
    inpday:'',
    bugtxt:'',
    isedit:false,
    edm:-1,
    edmemo:-1,
    edlunch:-1,
    edkubun:-1,
    eddest:-1,
    edperiod:-1,
    edsign1:-1,
    edsignd1:-1,
    edsign2:-1,
    edsignd2:-1,
    edremark:-1,
    employee:[],
    lunchdata:[],
    lchange:false,
    test:'test',
    addvisit:false,
    visitor:{"belong":"","name":"","tel":"","memo":"","alunch":"×","kubun":"","dest":"","period":"","sign1":"","signd1":"","sign2":"","signd2":"","remark":""},
    sche:[],
    lunchplus:0,
    detlunch:0,
    eddetlunch:false,
    holiday:[],
    bselect:0,
    res:0,
    lodr:[0],
    idbmax:0,
    waiting:false,
  },
  methods:{
    date_to_ja(str){
       s = str.split("-")
       return s[0]+"年"+(s[1]*1)+"月"+(s[2]*1)+"日("+ this.weekday_str(str) + ")"
    },
    date_to_str(date){
       return date.getFullYear() + "-" + ('0' + (date.getMonth() + 1)).slice(-2) + "-" + ('0' + date.getDate()).slice(-2)
    },
    date_to_sign(str){
      if(str != ""){
        s = str.split("-")
        return (s[1]*1)+"/"+(s[2]*1)
      }else{
        return ""
      }
    },
    weekday_str(str){
       return '日月火水木金土'[new Date(str).getDay()];
    },
    async dchange(){
      $(".popup")
      .addClass("show")
      .fadeIn();
      this.curday = this.inpday
      await ipcRenderer.invoke("DateChange",{curday:this.curday})
      .then((res)=>{
        this.sche = res
        if(res.length > 0){
          this.lodr = Array(1+Math.max(...res.map((p) => p.ide)))
          this.lodr.fill(-1)
          for(var i=0;i<res.length;i++){
            this.lodr[res[i].ide] = i
          }
        }
      })
      .catch((err)=>{
        alert(err)
      })
      await ipcRenderer.invoke("GetLunch",{curday:this.curday})
      .then((res)=>{
        this.lunchplus = res.addlunch
        this.detlunch = res.detlunch
        $(".popup").fadeOut();
      })
      .catch((err)=>{
        alert(err)
      })
    },
    async hprev(){
      d = new Date(this.curday)
      d.setDate( d.getDate() - 1 )
      this.curday = this.date_to_str(d)
      this.inpday = this.curday
      this.dchange()
    },
    async hnext(){
      d = new Date(this.curday)
      d.setDate( d.getDate() + 1 )
      this.curday = this.date_to_str(d)
      this.inpday = this.curday
      this.dchange()
    },
    editmemo(edid){
      if(this.edm == -1){
        this.isedit = true
        this.edm = edid
        this.edmemo = this.lodr[edid]
      }else if(this.edmemo != this.lodr[edid]){
        this.editfin(-1)
      }
    },
    editlunch(edid){
      if(this.edm == -1){
        this.isedit = true
        this.edm = edid
        this.edlunch = this.lodr[edid]
      }else if(this.edlunch != this.lodr[edid]){
        this.editfin(-1)
      }
    },
    editkubun(edid){
      if(this.edm == -1){
        this.isedit = true
        this.edm = edid
        this.edkubun = this.lodr[edid]
      }else if(this.edkubun != this.lodr[edid]){
        this.editfin(-1)
      }
    },
    editdest(edid){
      if(this.edm == -1){
        this.isedit = true
        this.edm = edid
        this.eddest = this.lodr[edid]
      }else if(this.eddest != this.lodr[edid]){
        this.editfin(-1)
      }
    },
    editperiod(edid){
      if(this.edm == -1){
        this.isedit = true
        this.edm = edid
        this.edperiod = this.lodr[edid]
      }else if(this.edperiod != this.lodr[edid]){
        this.editfin(-1)
      }
    },
    editsign1(edid){
      if(this.edm == -1){
        this.isedit = true
        this.edm = edid
        this.edsign1 = this.lodr[edid]
      }else if(this.edsign1 != this.lodr[edid]){
        this.editfin(-1)
      }
    },
    editsign2(edid){
      if(this.edm == -1){
        this.isedit = true
        this.edm = edid
        this.edsign2 = this.lodr[edid]
      }else if(this.edsign2 != this.lodr[edid]){
        this.editfin(-1)
      }
    },
    editremark(edid){
      if(this.edm == -1){
        this.isedit = true
        this.edm = edid
        this.edremark = this.lodr[edid]
      }else if(this.edremark != this.lodr[edid]){
        this.editfin()
      }
    },
    async editfin(emodr){
      if(this.edm != -1){
        this.edm = -1
        if(this.edmemo != -1){
          const name = this.sche[this.edmemo].name
          const ide = this.sche[this.edmemo].ide
          const sdate = this.sche[this.edmemo].sdate
          const changed = {"memo":this.sche[this.edmemo].memo}
          await ipcRenderer.invoke("ChangeSchedule",{ide:ide,name:name,sdate:sdate,changed:changed})
          .then((res)=>{
          })
          .catch((err)=>{
            alert(err)
          })
          this.edmemo = -1
        }else if(this.edlunch != -1){
          const name = this.sche[this.edlunch].name
          const ide = this.sche[this.edlunch].ide
          const sdate = this.sche[this.edlunch].sdate
          const changed = {"alunch":this.sche[this.edlunch].alunch}
          await ipcRenderer.invoke("ChangeSchedule",{ide:ide,name:name,sdate:sdate,changed:changed})
          .then((res)=>{
          })
          .catch((err)=>{
            alert(err)
          })
          this.edlunch = -1
        }else if(this.edkubun != -1){
          const name = this.sche[this.edkubun].name
          const ide = this.sche[this.edkubun].ide
          const sdate = this.sche[this.edkubun].sdate
          const changed = {"kubun":this.sche[this.edkubun].kubun,"sign1":"","signd1":"","sign2":"","signd2":""}
          //this.sche[this.edkubun].sign1 = ""
          //this.sche[this.edkubun].signd1 = ""
          //this.sche[this.edkubun].sign2 = ""
          //this.sche[this.edkubun].signd2 = ""
          changed.sign1 = this.sche[this.edkubun].sign1
          changed.signd1 = this.sche[this.edkubun].signd1
          changed.sign2 = this.sche[this.edkubun].sign2
          changed.signd2 = this.sche[this.edkubun].signd2
          changed.alunch = this.sche[this.edkubun].alunch
          await ipcRenderer.invoke("ChangeSchedule",{name:name,ide:ide,sdate:sdate,changed:changed})
          .then((res)=>{
          })
          .catch((err)=>{
            alert(err)
          })
          this.edkubun = -1
        }else if(this.eddest != -1){
          const name = this.sche[this.eddest].name
          const ide = this.sche[this.eddest].ide
          const sdate = this.sche[this.eddest].sdate
          const changed = {"dest":this.sche[this.eddest].dest,"sign1":"","signd1":"","sign2":"","signd2":""}
          //this.sche[this.eddest].sign1 = ""
          //this.sche[this.eddest].signd1 = ""
          //this.sche[this.eddest].sign2 = ""
          //this.sche[this.eddest].signd2 = ""
          changed.sign1 = this.sche[this.eddest].sign1
          changed.signd1 = this.sche[this.eddest].signd1
          changed.sign2 = this.sche[this.eddest].sign2
          changed.signd2 = this.sche[this.eddest].signd2
          await ipcRenderer.invoke("ChangeSchedule",{ide:ide,name:name,sdate:sdate,changed:changed})
          .then((res)=>{
          })
          .catch((err)=>{
            alert(err)
          })
          this.eddest = -1
        }else if(this.edperiod != -1){
          const name = this.sche[this.edperiod].name
          const ide  = this.sche[this.edperiod].ide
          const sdate = this.sche[this.edperiod].sdate
          const changed = {"period":this.sche[this.edperiod].period,"sign1":"","signd1":"","sign2":"","signd2":""}
          //this.sche[this.edperiod].sign1 = ""
          //this.sche[this.edperiod].signd1 = ""
          //this.sche[this.edperiod].sign2 = ""
          //this.sche[this.edperiod].signd2 = ""
          changed.sign1 = this.sche[this.edperiod].sign1
          changed.signd1 = this.sche[this.edperiod].signd1
          changed.sign2 = this.sche[this.edperiod].sign2
          changed.signd2 = this.sche[this.edperiod].signd2
          await ipcRenderer.invoke("ChangeSchedule",{ide:ide,name:name,sdate:sdate,changed:changed})
          .then((res)=>{
          })
          .catch((err)=>{
            alert(err)
          })
          this.edperiod = -1
        }else if(this.edsign1 != -1){
          const name = this.sche[this.edsign1].name
          const ide = this.sche[this.edsign1].ide
          const sdate = this.sche[this.edsign1].sdate
          const changed = {"sign1":this.sche[this.edsign1].sign1,"signd1":this.sche[this.edsign1].signd1}
          await ipcRenderer.invoke("ChangeSchedule",{ide:ide,name:name,sdate:sdate,changed:changed})
          .then((res)=>{
          })
          .catch((err)=>{
            alert(err)
          })
          this.edsign1 = -1
        }else if(this.edsign2 != -1){
          const name = this.sche[this.edsign2].name
          const ide = this.sche[this.edsign2].ide
          const sdate = this.sche[this.edsign2].sdate
          const changed = {"sign2":this.sche[this.edsign2].sign2,"signd2":this.sche[this.edsign2].signd2}
          await ipcRenderer.invoke("ChangeSchedule",{ide:ide,name:name,sdate:sdate,changed:changed})
          .then((res)=>{
          })
          .catch((err)=>{
            alert(err)
          })
          this.edsign2 = -1
        }else if(this.edremark != -1){
          const name = this.sche[this.edremark].name
          const ide = this.sche[this.edremark].ide
          const sdate = this.sche[this.edremark].sdate
          const changed = {"remark":this.sche[this.edremark].remark}
          await ipcRenderer.invoke("ChangeSchedule",{ide:ide,name:name,sdate:sdate,changed:changed})
          .then((res)=>{
          })
          .catch((err)=>{
            alert(err)
          })
          this.edremark = -1
        }
        this.isedit = false
      }
    },
    maru_to_bool(b){
      if(b == "○") return true
      else return false
    },
    bool_to_maru(b){
      if(b) return "○"
      else return "×"
    },
    watchlunch(edid){
      if(this.sche[edid].slunch != this.sche[edid].alunch) return true
      else return false
    },
    watchlunch2(slunch,alunch){
      if(slunch != alunch) return true
      else return false
    },
    setsign1: function (event,edid) {
      if (event) {
        const jj = this.lodr[edid]
        this.sche[jj].sign1 = event.target.value
        if(event.target.value != "") this.sche[jj].signd1 = this.today
        else this.sche[jj].signd1 = ""
      }
    },
    setsign2: function (event,edid) {
      if (event) {
        const jj = this.lodr[edid]
        this.sche[jj].sign2 = event.target.value
        if(event.target.value != "") this.sche[jj].signd2 = this.today
        else this.sche[jj].signd1 = ""
      }
    },
    visitsign1: function (event) {
      if (event) {
        this.visitor.sign1 = event.target.value
        if(event.target.value != "") this.visitor.signd1 = this.today
        else this.visitor.signd1 = ""
      }
    },
    visitsign2: function (event) {
      if (event) {
        this.visitor.sign2 = event.target.value
        if(event.target.value != "") this.visitor.signd2 = this.today
        else this.visitor.signd2 = ""
      }
    },
    ishol(){
      const curd = new Date(this.curday)
      let curh = this.holiday.filter(items => items.day == this.curday)
      if(curd.getDay() == 0 || curd.getDay() == 6 || curh.length > 0) return true
      else return false
    },
    async addDB(){
      let adat = {"odr":Math.max(...this.sche.map((p) => p.odr))+1,"idb":this.idbmax,"slunch":"×","sdate":this.curday}
      adat.belong = this.visitor.belong
      adat.name = this.visitor.name
      adat.tel = this.visitor.tel
      adat.memo = this.visitor.memo
      adat.alunch = this.visitor.alunch
      adat.kubun = this.visitor.kubun
      adat.dest = this.visitor.dest
      adat.period = this.visitor.period
      adat.sign1 = this.visitor.sign1
      adat.signd1 = this.visitor.signd1
      adat.sign2 = this.visitor.sign2
      adat.signd2 = this.visitor.signd2
      adat.remark = this.visitor.remark
      aide = Math.max(...this.sche.map((p)=>p.ide))+1
      if(aide > 1000) adat.ide = aide
      else adat.ide = 1000
      let fil = this.belong.filter(items => items.name == this.visitor.belong)
      if(fil.length > 0) adat.idb = fil[0].idb
      if(this.ishol()){
        let fil2 = this.employee.filter(items => items.name == this.visitor.name)
        if(fil2.length > 0){
          if(adat.period == ""){
            alert("出社時刻を記入してください")
            return false
          }
          adat.odr = fil2[0].odr
          adat.ide = fil2[0].ide
        }else{
          if(adat.idb != this.idbmax){
            alert("名前を正確に記入してください")
            return false
          }
        }
      }
      this.addvisit = false
      await ipcRenderer.invoke("ChangeSchedule",{ide:adat.ide,name:adat.name,sdate:this.curday,changed:adat})
      this.sche.push(adat)
      this.lodr[adat.ide] = this.sche.length-1
      this.resetvisitor()
      await editfin()
    },
    countlunch_maru(){
      const fil = this.sche.filter(function(s){
        return s.alunch == "○"
      })
      return fil.length
    },
    countlunch_badtz(){
      const fil = this.sche.filter(function(s){
        return s.alunch == "×"
      })
      return fil.length
    },
    countlunch_sum(){
      return parseInt(this.countlunch_maru()) + parseInt(this.lunchplus)
    },
    count_kubun(txt){
      const fil = this.sche.filter(function(s){
        return s.kubun == txt
      })
      return fil.length
    },
    count_kubun2(txt,idb){
      const fil = this.sche.filter(function(s){
        return s.kubun == txt && s.idb == (idb+1)
      })
      return fil.length
    },
    detlunchcolor(){
      if(this.detlunch>0) return true
      else return false
    },
    async detlunchbutton(){
      this.eddetlunch = false
      await ipcRenderer.invoke("SetLunch",{sdate:this.curday,addlunch:this.lunchplus,detlunch:this.detlunch})
      .then((res)=>{})
      .catch((err)=>{
        alert(err)
      })
    },
    async lunchplusdb(event){
      if(event){
          this.lunchplus = event.target.value
          await ipcRenderer.invoke("SetLunch",{sdate:this.curday,addlunch:this.lunchplus,detlunch:this.detlunch})
          .then((res)=>{})
          .catch((err)=>{
            alert(err)
          })
      }
    },
    resetvisitor(){
      this.visitor = {"belong":"","name":"","tel":"","memo":"","alunch":"×","kubun":"","dest":"","period":"","sign1":"","signd1":"","sign2":"","signd2":"","remark":""}
    },
    setvisitorrow(idb){
      if(this.addvisit==false && idb==this.idbmax) return true
      else return false
    },
    async delsche(delid){
      await ipcRenderer.invoke("DeleteSchedule",{sdate:this.curday,name:this.sche[delid].name,ide:this.sche[delid].ide})
      .then((res)=>{
        this.sche.splice(delid,1)
      })
      .catch((err)=>{
        alert(err)
      })
    },
    daycolor(){
      wk = new Date(this.curday).getDay()
      if(wk == 0) return "red"
      else if(wk == 6) return "blue"
      else if(this.ishol()) return "red"
      else return "black"
    },
    sche_div(idb){
      let ds = this.sche.filter(items => items.idb == (idb+1))
      return ds
    },
    opentable(idb){
      $('#collapseTable'+idb).collapse('show')
    },
    bopen(idb){
      if(this.bselect == idb) return "collapse show"
      else return "collapse"
    },
    async sendbelong(idb){
      await ipcRenderer.invoke("SendSelectedBelong",idb)
      .then((res)=>{
        this.bselect = res
        setTimeout(function(){
          window.location.href = "#belong"+res
        },100)
      })
      .catch((err)=>{
        alert(err)
      })
    },
    async sendbelong2(embe){
      let bel = this.belong.filter(items => items.name == embe)
      if(bel.length > 0) await this.sendbelong(bel[0].idb-1)
    },
    kubunchange(event,emodr){
      const jj = this.lodr[emodr]
      if(event){
        this.sche[jj].kubun = event.target.value
        this.sche[jj].sign1 = ""
        this.sche[jj].signd1 = ""
        this.sche[jj].sign2 = ""
        this.sche[jj].signd2 = ""
        if(event.target.value == "テレワーク" || event.target.value == "休暇" || event.target.value=="海外出張"){
          this.sche[jj].alunch = "×"
        }
      }
    },
    destchange(event,emodr){
      const jj = this.lodr[emodr]
      if(event){
        this.sche[jj].dest = event.target.value
        this.sche[jj].sign1 = ""
        this.sche[jj].signd1 = ""
        this.sche[jj].sign2 = ""
        this.sche[jj].signd2 = ""
      }
    },
    periodchange(event,emodr){
      const jj = this.lodr[emodr]
      if(event){
        this.sche[jj].period = event.target.value
        this.sche[jj].sign1 = ""
        this.sche[jj].signd1 = ""
        this.sche[jj].sign2 = ""
        this.sche[jj].signd2 = ""
      }
    },
  }
})
