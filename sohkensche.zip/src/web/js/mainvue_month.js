const {ipcRenderer,shell} = require('electron')

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})

async function tohome(){
  await ipcRenderer.invoke("toHome")
}

// 利用方法
async function howto(){
  shell.openItem(process.cwd()+"\\manual.pdf")
  //alert(process.cwd()+"\\manual.pdf")
}
// 不具合報告
$('#button_bugsend').on("click",async function(){
  const str1 = $('textarea[name="bugtxt"]').val();
  await ipcRenderer.invoke("BugSend",{txt:str1.replace(/\r?\n/g, '<br>')})
  .then((res)=>{
    //alert(res)
  })
  .catch((err) => {
    alert(err)
  })
  $('textarea[name="bugtxt"]').val("")
})

var maincontent = new Vue({
  el: '#maincontent',
  async mounted(){
    await ipcRenderer.invoke("GetBelong")
    .then((res)=>{
      this.belong = res
      this.idbmax = Math.max(...res.map((p)=> p.idb))
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("GetEmployee")
    .then((res)=>{
      this.employee = res
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("GetDaySchedule")
    .then((res)=>{
      this.sche = res
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("GetLunch",{curday:''})
    .then((res)=>{
      this.lunchplus = res.addlunch
      this.detlunch = res.detlunch
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("getTodayVue")
    .then((res)=>{
      this.today = res
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("getCurday")
    .then((res)=>{
      this.curday = res
      this.inpday = res
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("GetHoliday")
    .then((res)=>{
      this.holiday = res
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("GetSelectedBelong")
    .then((res)=>{
      this.bselect = res
      if(res != -1 && !this.ishol()){
        setTimeout(function(){
          window.location.href = "#belong"+res
        },100)
      }
    })
    .catch((err)=>{
        alert(err)
    })
    await ipcRenderer.invoke("GetMonth")
    .then((res)=>{
      this.curmonth = res
      this.monthname = res[0]
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("GetMonthSchedule")
    .then((res)=>{
      this.sche_m = res
      this.sche_m2 = this.sche_align(res)
    })
    .catch((err)=>{
      alert(err)
    })
    $('[data-toggle="tooltip"]').tooltip()
  },
  data: {
    belong:[],
    today:'',
    curday:'',
    inpday:'',
    bugtxt:'',
    isedit:false,
    edm:-1,
    edmemo:-1,
    edlunch:-1,
    edkubun:-1,
    eddest:-1,
    edperiod:-1,
    edsign1:-1,
    edsignd1:-1,
    edsign2:-1,
    edsignd2:-1,
    edremark:-1,
    employee:[],
    lunchdata:[],
    lchange:false,
    test:'test',
    addvisit:false,
    visitor:{"belong":"","name":"","tel":"","memo":"","alunch":"×","kubun":"","dest":"","period":"","sign1":"","signd1":"","sign2":"","signd2":"","remark":""},
    sche:[],
    lunchplus:0,
    detlunch:0,
    eddetlunch:false,
    holiday:[],
    bselect:0,
    idbmax:0,
    res:0,
    lodr:[0],
    curmonth:[],
    sche_m:[],
    sche_m2:[],
    monthname:"",
    edsdate:"",
    edm_s:[],
  },
  methods:{
    date_to_ja(str){
       s = str.split("-")
       return s[0]+"年"+(s[1]*1)+"月"+(s[2]*1)+"日("+ this.weekday_str(str) + ")"
    },
    date_to_str(date){
       return date.getFullYear() + "-" + ('0' + (date.getMonth() + 1)).slice(-2) + "-" + ('0' + date.getDate()).slice(-2)
    },
    date_to_sign(str){
      if(str != ""){
        s = str.split("-")
        return (s[1]*1)+"/"+(s[2]*1)
      }else{
        return ""
      }
    },
    weekday_str(str){
       return '日月火水木金土'[new Date(str).getDay()];
    },
    async dchange(){
      this.curday = this.inpday
      await ipcRenderer.invoke("DateChange",{curday:this.curday})
      .then((res)=>{
        this.sche = res
      })
      .catch((err)=>{
        alert(err)
      })
      await ipcRenderer.invoke("GetLunch",{curday:this.curday})
      .then((res)=>{
        this.lunchplus = res.addlunch
        this.detlunch = res.detlunch
      })
      .catch((err)=>{
        alert(err)
      })
    },
    async hprev(){
      d = new Date(this.curday)
      d.setDate( d.getDate() - 1 )
      this.curday = this.date_to_str(d)
      this.inpday = this.curday
      this.dchange()
    },
    async hnext(){
      d = new Date(this.curday)
      d.setDate( d.getDate() + 1 )
      this.curday = this.date_to_str(d)
      this.inpday = this.curday
      this.dchange()
    },
    maru_to_bool(b){
      if(b == "○") return true
      else return false
    },
    bool_to_maru(b){
      if(b) return "○"
      else return "×"
    },
    watchlunch(edid){
      if(this.sche[edid].slunch != this.sche[edid].alunch) return true
      else return false
    },
    watchlunch2(slunch,alunch){
      if(slunch != alunch) return true
      else return false
    },
    visitsign1: function (event) {
      if (event) {
        this.visitor.sign1 = event.target.value
        if(event.target.value != "") this.visitor.signd1 = this.today
        else this.visitor.signd1 = ""
      }
    },
    visitsign2: function (event) {
      if (event) {
        this.visitor.sign2 = event.target.value
        if(event.target.value != "") this.visitor.signd2 = this.today
        else this.visitor.signd2 = ""
      }
    },
    ishol(){
      const curd = new Date(this.curday)
      let curh = this.holiday.filter(items => items.day == this.curday)
      if(curd.getDay() == 0 || curd.getDay() == 6 || curh.length > 0) return true
      else return false
    },
    countlunch_maru(){
      const fil = this.sche.filter(function(s){
        return s.alunch == "○"
      })
      return fil.length
    },
    countlunch_badtz(){
      const fil = this.sche.filter(function(s){
        return s.alunch == "×"
      })
      return fil.length
    },
    countlunch_sum(){
      return parseInt(this.countlunch_maru()) + parseInt(this.lunchplus)
    },
    count_kubun(txt){
      const fil = this.sche.filter(function(s){
        return s.kubun == txt
      })
      return fil.length
    },
    count_kubun2(txt,idb){
      const fil = this.sche.filter(function(s){
        return s.kubun == txt && s.idb == (idb+1)
      })
      return fil.length
    },
    detlunchcolor(){
      if(this.detlunch>0) return true
      else return false
    },
    async detlunchbutton(){
      this.eddetlunch = false
      await ipcRenderer.invoke("SetLunch",{sdate:this.curday,addlunch:this.lunchplus,detlunch:this.detlunch})
      .then((res)=>{})
      .catch((err)=>{
        alert(err)
      })
    },
    async lunchplusdb(event){
      if(event){
          this.lunchplus = event.target.value
          await ipcRenderer.invoke("SetLunch",{sdate:this.curday,addlunch:this.lunchplus,detlunch:this.detlunch})
          .then((res)=>{})
          .catch((err)=>{
            alert(err)
          })
      }
    },
    resetvisitor(){
      this.visitor = {"belong":"","name":"","tel":"","memo":"","alunch":"×","kubun":"","dest":"","period":"","sign1":"","signd1":"","sign2":"","signd2":"","remark":""}
    },
    setvisitorrow(idb){
      if(this.addvisit==false && idb==this.idbmax) return true
      else return false
    },
    async delsche(delid){
      await ipcRenderer.invoke("DeleteSchedule",{sdate:this.curday,name:this.sche[delid].name,ide:this.sche[delid].ide})
      .then((res)=>{
        this.sche.splice(delid,1)
      })
      .catch((err)=>{
        alert(err)
      })
    },
    daycolor(){
      wk = new Date(this.curday).getDay()
      if(wk == 0) return "red"
      else if(wk == 6) return "blue"
      else if(this.ishol()) return "red"
      else return "black"
    },
    sche_div(idb){
      let ds = this.sche.filter(items => items.idb == (idb+1))
      return ds
    },
    opentable(idb){
      $('#collapseTable'+idb).collapse('show')
    },
    bopen(idb){
      if(this.bselect == idb) return "collapse show"
      else return "collapse"
    },
    async sendbelong(idb){
      await ipcRenderer.invoke("SendSelectedBelong",idb)
      .then((res)=>{
        this.bselect = res
        if(res != -1){
          setTimeout(function(){
            window.location.href = "#belong"+res
          },100)
        }
      })
      .catch((err)=>{
        alert(err)
      })
    },
    async sendbelong2(embe){
      let bel = this.belong.filter(items => items.name == embe)
      if(bel.length > 0) await this.sendbelong(bel[0].idb-1)
    },
    kubunchange_m(event){
      if(event){
        this.edm_s.kubun = event.target.value
        this.edm_s.sign1 = ""
        this.edm_s.signd1 = ""
        this.edm_s.sign2 = ""
        this.edm_s.signd2 = ""
        if(event.target.value == "テレワーク" || event.target.value == "休暇" || event.target.value=="海外出張"){
          this.edm_s.alunch = "×"
        }
      }
    },
    destchange_m(event){
      if(event){
        this.edm_s.dest = event.target.value
        this.edm_s.sign1 = ""
        this.edm_s.signd1 = ""
        this.edm_s.sign2 = ""
        this.edm_s.signd2 = ""
      }
    },
    periodchange_m(event,emodr){
      if(event){
        this.edm_s.period = event.target.value
        this.edm_s.sign1 = ""
        this.edm_s.signd1 = ""
        this.edm_s.sign2 = ""
        this.edm_s.signd2 = ""
      }
    },
    thhol(d){
      i = new Date(d).getDay()
      if(i == 6) return "saturday1"
      else if(i == 0) return "sunday1"
      else if(this.ishol2(d)) return "sunday1"
      else return "workday"
    },
    tdhol(d){
      i = new Date(d).getDay()
      if(i == 6) return "saturday2"
      else if(i == 0) return "sunday2"
      else if(this.ishol2(d)) return "sunday2"
      else if(d == this.today) return "tdtoday"
      else return "workday"
    },
    thhol2(d){
      i = new Date(d).getDay()
      if(i == 6) return "#eef"
      else if(i == 0) return "#fee"
      else if(this.ishol2(d)) return "#fee"
      else if(d == this.today) return "#efe"
      else return ""
    },
    ishol2(sdate){
      const curd = new Date(sdate)
      let curh = this.holiday.filter(items => items.day == sdate)
      if(curd.getDay() == 0 || curd.getDay() == 6 || curh.length > 0) return true
      else return false
    },
    date_to_ja3(str){
       s = str.split("-")
       return s[0]+"年"+(s[1]*1)+"月"
    },
    date_to_ja4(str){
      s = str.split("-")
      return (s[2]*1)
    },
    async dchange2(dump,idb){
      this.curday = dump
      await ipcRenderer.invoke("DateChange",{curday:this.curday})
      .then((res)=>{
        this.sche = res
      })
      .catch((err)=>{
        alert(err)
      })
      await ipcRenderer.invoke("GetLunch",{curday:this.curday})
      .then((res)=>{
        this.lunchplus = res.addlunch
        this.detlunch = res.detlunch
      })
      .catch((err)=>{
        alert(err)
      })
      if(idb != 0 && idb != this.belong.length-1){
        await this.sendbelong(idb)
      }
    },
    sche_align(arr){
      let nosche = {"kubun":"","period":"","dest":"","memo":"","sign1":"","signd1":"","sign2":"","signd2":"","remark":"","sdate":""}
      let ar = arr.concat()
      let emp = []
      for(var i=0;i<ar.length;i++){
        let iadd = true
        for(var j=i+1;j<ar.length;j++){
          if(ar[i].ide == ar[j].ide) iadd = false
        }
        if(iadd) emp.push({"name":ar[i].name,"belong":ar[i].belong,"idb":ar[i].idb,"odr":ar[i].odr,"ide":ar[i].ide})
      }
      emp.sort((a, b) => a.odr - b.odr)
      for(var i=0;i<emp.length;i++){
        let fil = arr.filter(items => items.ide == emp[i].ide)
        let tmp = []
        for(var j=0;j<this.curmonth.length;j++){
          let nosche2 = Object.assign({},nosche)
          nosche2.sdate = this.curmonth[j]
          let fil2 = fil.filter(items => items.sdate == this.curmonth[j])
          if(fil2.length > 0){
            if(fil2[0].kubun==null || (this.ishol2(fil2[0].sdate) && fil2[0].period != "")) fil2[0].kubun = "出勤"
            if(fil2[0].dest==null) fil2[0].dest = ""
            if(fil2[0].period==null) fil2[0].period = ""
            tmp.push(fil2[0])
          }
          else tmp.push(nosche2)
        }
        emp[i].m_s = tmp
      }
      return emp
    },
    async hprev_m(){
      d = new Date(this.curday)
      d.setMonth( d.getMonth() - 1 )
      this.curday = this.date_to_str(d)
      this.inpday = this.curday
      await this.mchange()
    },
    async hnext_m(){
      d = new Date(this.curday)
      d.setMonth( d.getMonth() + 1 )
      this.curday = this.date_to_str(d)
      this.inpday = this.curday
      await this.mchange()
    },
    async mchange(){
      this.curday = this.inpday
      await ipcRenderer.invoke("MonthChange",{curday:this.curday})
      .then((res)=>{
        this.curmonth = res.curmonth
        if(this.curday != this.today) this.inpday = res.curmonth[0]
        this.monthname = res.curmonth[0]
        if(res.curmonth.indexOf(this.today)!=-1) this.curday = this.today
        else this.curday = res.curmonth[0]
        this.sche_m = res.sche_m
        this.sche_m2 = this.sche_align(res.sche_m)
        if(this.bselect){
          const bsel = this.bselect
          setTimeout(function(){
            window.location.href = "#belong"+bsel
          },100)
        }
        Vue.nextTick(() => {
          $('[data-toggle="tooltip"]').tooltip()
        })
      })
      .catch((err)=>{
        alert(err)
      })
    },
    editdialog3(emide,j_m_s){
      this.edm = this.sche_m2.findIndex(({ide}) => ide === emide)
      this.edsdate = this.curmonth[j_m_s]
      this.edm_s = this.sche_m2[this.edm].m_s[j_m_s]
      delete this.edm_s._id
      this.edw = false
      $('#editModal').modal('show')
    },
    edname(){
      if(this.edm == -1) return ""
      else return this.sche_m2[this.edm].name
    },
    edday(){
      const ds = this.edsdate.split("-")
      return (ds[1]*1) + "/" + (ds[2]*1) + "(" + this.weekday_str(this.edsdate) + ")"
    },
    async changemonthschedule(){
      if(this.ishol2(this.edm_s.sdate) && this.edm_s.period == ""){
        await this.delsche2()
      }else{
        if(this.ishol2(this.edm_s.sdate)){
          this.edm_s.name = this.sche_m2[this.edm].name
          this.edm_s.belong = this.sche_m2[this.edm].belong
          this.edm_s.idb = this.sche_m2[this.edm].idb
          this.edm_s.odr = this.sche_m2[this.edm].odr
          this.edm_s.ide = this.sche_m2[this.edm].ide
        }
        await ipcRenderer.invoke("ChangeSchedule",{ide:this.edm_s.ide,name:this.edm_s.name,sdate:this.edm_s.sdate,changed:this.edm_s})
        .then((res)=>{
          this.mchange()
        })
        .catch((err)=>{alert(err)})
      }
    },
    async delsche2(){
      let nosche = {"kubun":"","period":"","dest":"","memo":"","sign1":"","signd1":"","sign2":"","signd2":"","remark":"","sdate":this.edm_s.sdate}
      await ipcRenderer.invoke("DeleteSchedule",{sdate:this.edm_s.sdate,name:this.edm_s.name,ide:this.edm_s.ide})
      .then((res)=>{
        this.edm_s = nosche
        this.mchange()
      })
      .catch((err)=>{
        alert(err)
      })
    },
    sche_m_div(idb){
      let ds = this.sche_m2.filter(items => items.idb == (idb+1))
      return ds
    },
  }
})
