const {ipcRenderer,shell} = require('electron')

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})

async function tohome(){
  await ipcRenderer.invoke("toHome")
}

// 利用方法
async function howto(){
  shell.openItem(process.cwd()+"\\manual.pdf")
  //alert(process.cwd()+"\\manual.pdf")
}
// 不具合報告
$('#button_bugsend').on("click",async function(){
  const str1 = $('textarea[name="bugtxt"]').val();
  await ipcRenderer.invoke("BugSend",{txt:str1.replace(/\r?\n/g, '<br>')})
  .then((res)=>{
    //alert(res)
  })
  .catch((err) => {
    alert(err)
  })
  $('textarea[name="bugtxt"]').val("")
})

var holidayvue = new Vue({
  el: '#holiday',
  async mounted(){
//    await eel.getTodayVue()((res) =>{
    await ipcRenderer.invoke("getTodayVue")
    .then((res)=>{
      this.yy = res.split('-')[0]
    })
    .catch((err)=>{
      alert(err)
    })
//    await eel.HolidayList(this.yy)((res) => {
    await ipcRenderer.invoke("HolidayList",this.yy)
    .then((res)=>{
      this.lst = res
    })
    .catch((err)=>{
      alert(err)
    })
    const date  = new Date();
    [this.currentYear,  this.currentMonth, this.currentDate] = [this.yy, date.getMonth() + 1, date.getDate()];
  },
  data: {
    lst:[],
    yy:2020,
    res:0,
    today:"",
    selectedDay:"",
    currentYear:0,
    currentMonth:0,
    currentDate:0,
    weeks:["日","月","火","水","木","金","土"],
    calendar:[],
    holidays:[],
    ladd:[],
    ldel:[],
  },
  methods: {
    m_calendar(month){
      const firstday = new Date(this.yy,month,1).getDay();
      const lastdate = new Date(this.yy,month+1,0).getDate();
//      const necessarySpace = firstday == 0 ? 6 : firstday - 1;
      const necessarySpace = firstday;
      const list = [[...Array(necessarySpace)].map(i=>" "), [...Array(lastdate)].map((_, i) => i+1)];
      const week = list.reduce((pre,current) => {pre.push(...current);return pre},[]);
      return this.listToMatrix(week,7)
    },
    listToMatrix(list, elementsPerSubArray) {
        var matrix = [], i, k;
        for (i = 0, k = -1; i < list.length; i++) {
            if (i % elementsPerSubArray === 0) {
                k++;
                matrix[k] = [];
            }
            matrix[k].push(list[i]);
        }
        return matrix;
    },
    txtcolor(i){
      if(i == 0) return 'sun'
      if(i == 6) return 'satur'
    },
    backcolor(m,d){
      for(let i = 0;i<this.lst.length;i++){
        if(Number(this.lst[i].split('-')[1]) == m && Number(this.lst[i].split('-')[2]) == d) return this.lcheck(m,d)
      }
      for(let i = 0;i<this.ladd.length;i++){
        if(Number(this.ladd[i].split('-')[1]) == m && Number(this.ladd[i].split('-')[2]) == d) return 'holi'
      }
    },
    lcheck(m,d){
      exist = false
      for(let i = 0;i<this.ldel.length;i++){
        if(Number(this.ldel[i].split('-')[1]) == m && Number(this.ldel[i].split('-')[2]) == d) exist = true
      }
      if(!exist) return 'holi'
    },
    classget(i,m,d){
      return this.txtcolor(i) + ' ' + this.backcolor(m,d)
    },
    async prev(){
      this.yy--
//      await eel.HolidayList(this.yy)((res) => {
      await ipcRenderer.invoke("HolidayList",this.yy)
      .then((res)=>{
        this.lst = res
      })
      .catch((err)=>{
        alert(err)
      })
    },
    async next(){
      this.yy++
//      await eel.HolidayList(this.yy)((res) => {
      await ipcRenderer.invoke("HolidayList",this.yy)
      .then((res)=>{
        this.lst = res
      })
      .catch((err)=>{
        alert(err)
      })
    },
    addlst(i2,m,d){
      hol = this.yy + '-' + ( '00' + m ).slice( -2 ) + '-' + ( '00' + d ).slice( -2 );
      exist = false
      exist2 = false
      if(d!=0){
        for(let i = 0;i<this.lst.length;i++){
          if(this.lst[i] == hol){
            exist = true
            for(let j = 0;j<this.ldel.length;j++){
              if(this.ldel[j] == hol){
                exist2 = true
                this.ldel.splice(j,1)
              }
            }
            if(!exist2) this.ldel.push(hol)
          }
        }
        if(!exist){
          for(let i = 0;i<this.ladd.length;i++){
            if(this.ladd[i] == hol){
              this.ladd.splice(i,1);
              exist = true;
            }
          }
          if(!exist && i2 != 0 && i2 != 6) this.ladd.push(hol);
        }
      }
    },
    async sethol(){
      l1 = this.ladd.length
      l2 = this.ldel.length
      if(l1 > 0){
//        await eel.SetHoliday(this.ladd)((res) => {
        await ipcRenderer.invoke("SetHoliday",this.ladd)
        .then((res)=>{
          this.res = res
          this.ladd = []
        })
        .catch((err)=>{
          alert(err)
        })
      }
      if(l2 > 0){
//        await eel.DeleteHoliday(this.ldel)((res) => {
        await ipcRenderer.invoke("DeleteHoliday",this.ldel)
        .then((res)=>{
          this.res = res
          this.ldel = []
        })
        .catch((err)=>{
          alert(err)
        })
      }
      alert("更新しました。追加"+l1+"件、削除"+l2+"件")
//      await eel.HolidayList(this.yy)((res) => {
      await ipcRenderer.invoke("HolidayList",this.yy)
      .then((res)=>{
        this.lst = res
      })
      .catch((err)=>{
        alert(err)
      })
    },
  },
})
var maincontent = new Vue({
  el: '#maincontent',
  async mounted(){
    await ipcRenderer.invoke("GetBelong")
    .then((res)=>{
      this.belong = res
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("GetEmployee")
    .then((res)=>{
      this.employee = res
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("getTodayVue")
    .then((res)=>{
      this.today = res
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("getCurday")
    .then((res)=>{
      this.curday = res
      this.inpday = res
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("GetHoliday")
    .then((res)=>{
      this.holiday = res
    })
    .catch((err)=>{
      alert(err)
    })
    await ipcRenderer.invoke("GetSelectedBelong")
    .then((res)=>{
      this.bselect = res
      if(res != -1 && !this.ishol()){
        setTimeout(function(){
          window.location.href = "#belong"+res
        },100)
      }
    })
    .catch((err)=>{
        alert(err)
    })
    $('[data-toggle="tooltip"]').tooltip()
  },
  data: {
    belong:[],
    today:'',
    curday:'',
    inpday:'',
    bugtxt:'',
    isedit:false,
    edm:-1,
    edmemo:-1,
    edlunch:-1,
    edkubun:-1,
    eddest:-1,
    edperiod:-1,
    edsign1:-1,
    edsignd1:-1,
    edsign2:-1,
    edsignd2:-1,
    edremark:-1,
    employee:[],
    lunchdata:[],
    lchange:false,
    test:'test',
    addvisit:false,
    visitor:{"belong":"","name":"","tel":"","memo":"","alunch":"×","kubun":"","dest":"","period":"","sign1":"","signd1":"","sign2":"","signd2":"","remark":""},
    sche:[],
    lunchplus:0,
    detlunch:0,
    eddetlunch:false,
    holiday:[],
    bselect:0,
    res:0,
    lodr:[0],
  },
  methods:{
    date_to_ja(str){
       s = str.split("-")
       return s[0]+"年"+(s[1]*1)+"月"+(s[2]*1)+"日("+ this.weekday_str(str) + ")"
    },
    date_to_str(date){
       return date.getFullYear() + "-" + ('0' + (date.getMonth() + 1)).slice(-2) + "-" + ('0' + date.getDate()).slice(-2)
    },
    date_to_sign(str){
      if(str != ""){
        s = str.split("-")
        return (s[1]*1)+"/"+(s[2]*1)
      }else{
        return ""
      }
    },
    weekday_str(str){
       return '日月火水木金土'[new Date(str).getDay()];
    },
    maru_to_bool(b){
      if(b == "○") return true
      else return false
    },
    bool_to_maru(b){
      if(b) return "○"
      else return "×"
    },
    watchlunch(edid){
      if(this.sche[edid].slunch != this.sche[edid].alunch) return true
      else return false
    },
    watchlunch2(slunch,alunch){
      if(slunch != alunch) return true
      else return false
    },
    ishol(){
      const curd = new Date(this.curday)
      let curh = this.holiday.filter(items => items.day == this.curday)
      if(curd.getDay() == 0 || curd.getDay() == 6 || curh.length > 0) return true
      else return false
    },
    countlunch_maru(){
      const fil = this.sche.filter(function(s){
        return s.alunch == "○"
      })
      return fil.length
    },
    countlunch_badtz(){
      const fil = this.sche.filter(function(s){
        return s.alunch == "×"
      })
      return fil.length
    },
    countlunch_sum(){
      return parseInt(this.countlunch_maru()) + parseInt(this.lunchplus)
    },
    count_kubun(txt){
      const fil = this.sche.filter(function(s){
        return s.kubun == txt
      })
      return fil.length
    },
    count_kubun2(txt,idb){
      const fil = this.sche.filter(function(s){
        return s.kubun == txt && s.idb == (idb+1)
      })
      return fil.length
    },
    detlunchcolor(){
      if(this.detlunch>0) return true
      else return false
    },
    async detlunchbutton(){
      this.eddetlunch = false
      await ipcRenderer.invoke("SetLunch",{sdate:this.curday,addlunch:this.lunchplus,detlunch:this.detlunch})
      .then((res)=>{})
      .catch((err)=>{
        alert(err)
      })
    },
    async lunchplusdb(event){
      if(event){
          this.lunchplus = event.target.value
          await ipcRenderer.invoke("SetLunch",{sdate:this.curday,addlunch:this.lunchplus,detlunch:this.detlunch})
          .then((res)=>{})
          .catch((err)=>{
            alert(err)
          })
      }
    },
    async delsche(delid){
      await ipcRenderer.invoke("DeleteSchedule",{sdate:this.curday,name:this.sche[delid].name})
      .then((res)=>{
        this.sche.splice(delid,1)
      })
      .catch((err)=>{
        alert(err)
      })
    },
    daycolor(){
      wk = new Date(this.curday).getDay()
      if(wk == 0) return "red"
      else if(wk == 6) return "blue"
      else if(this.ishol()) return "red"
      else return "black"
    },
    sche_div(idb){
      let ds = this.sche.filter(items => items.idb == (idb+1))
      return ds
    },
    opentable(idb){
      $('#collapseTable'+idb).collapse('show')
    },
    bopen(idb){
      if(this.bselect == idb) return "collapse show"
      else return "collapse"
    },
    async sendbelong(idb){
      await ipcRenderer.invoke("SendSelectedBelong",idb)
      .then((res)=>{
        this.bselect = res
        setTimeout(function(){
          window.location.href = "#belong"+res
        },100)
      })
      .catch((err)=>{
        alert(err)
      })
    },
    async sendbelong2(embe){
      let bel = this.belong.filter(items => items.name == embe)
      if(bel.length > 0) await this.sendbelong(bel[0].idb-1)
    },
  }
})
