const {ipcRenderer,shell} = require('electron')

// ホーム
async function button_home(){
//      let val = await eel.PostDateNavi('',0)()
  let val = await ipcRenderer.invoke("PostDateNavi",{date:"",tabs:0})
}
// 予定印刷
async function printPDF(){
//      let val = await eel.GetPDF()((res) => {
  let val = await ipcRenderer.invoke("GetPDF")
  .then((res)=>{
    const fn = function(){
      window.open(res,'_blank','scrollbars=1,location=0,menubar=0,toolbar=0,status=1,directories=0,resizable=1')
    }
    setTimeout(fn,100)
  })
  .catch((err)=>{
    alert(err)
  })
}
// 子ウインドウからの更新処理
window.addEventListener('message', (e) => {
  window.location.reload()
})

// データベース容量削減
$('#dbclean').on("click", async function() {
//  let val = await eel.CleanDatabase()((res) => {
  let res = await ipcRenderer.invoke("CleanDatabase")
  .then((res)=>{
    alert(res+'件のデータベースを削除しました')
  })
  .catch((err)=>{
    alert(err)
  })
});
// データ取り込みマクロ起動
$('#openmacro').on("click",async function(){
//  alert(process.cwd()+"\\dataget.xlsm")
  shell.openItem(process.cwd()+"\\dataget.xlsm")
})
// マニュアル
$('#manual').on("click",async function(){
  shell.openItem(process.cwd()+"\\dev_manual.docx")
})
// 利用方法
$('#howto').on("click",async function(){
  shell.openItem(process.cwd()+"\\manual.pdf")
})

/*$('#reset').on("click", async function() {
  if(window.confirm("データベースをリセットしてよろしいですか？")){
    let val = await ipcRenderer.invoke("ResetDB")
  }
})*/
