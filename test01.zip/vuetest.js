var app = new Vue({
  el: "#vuetest",
  data() {
    return {
      message: "VUE test"
    }
  },
  methods:{
    async btntest(){
      const data = await window.api.send("msg_render_to_main2", {teamName: "Victories"});
      console.log(data)
    }
  }
});
