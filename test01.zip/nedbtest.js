const Datastore = require('nedb');
const db = new Datastore({
    filename: 'namelist.db',
    autoload:true
});
db.loadDatabase(function(err){
  // コマンドが実行される
  if (err !== null) {
    console.error(err);
  }
  console.log("load database completed.");
});

function inserttest(){
  const doc = {
      name:'test01',
      age:11
  };
  db.insert(doc, function(err, newDocs){
    if (err !== null) {
      console.error(err);
    }
    console.log("insert database completed.");
  });
}
function disptest(){
  db.find({ name: "test01" }, (error, docs) => {
     console.log("find database completed.");
     console.log(docs)
  });
}
