class Urashimasan {
  read() {
    console.log('Urashimasan says "亀の甲羅に腰かけるなどは、それは狂態と言つてよからう。"')
  }
}

module.exports = Urashimasan;
