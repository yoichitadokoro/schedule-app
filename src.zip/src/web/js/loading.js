const {ipcRenderer} = require('electron')
window.onload = async function(){
  await ipcRenderer.invoke('Loading')
  .then((res)=>{
    alert(res)
  })
  .then((res)=>{
    location.href = "main.html"
  })
  .catch((err)=>{
    alert(err)
  })
}
