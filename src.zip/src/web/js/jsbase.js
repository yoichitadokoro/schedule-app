'use strict'
const {ipcRenderer} = require('electron')

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
// 新規予定
$("a[id^=newblow]").click(function(){
    window.open('newblow.html','_blank','width=600,height=750,scrollbars=1,location=0,menubar=0,toolbar=0,status=1,directories=0,resizable=1,left='+(window.screen.width-600)/2+',top='+(window.screen.height-700)/4);
    return false;
});
$("a[id^=newinj]").click(function(){
    window.open('newinj.html','_blank','width=600,height=750,scrollbars=1,location=0,menubar=0,toolbar=0,status=1,directories=0,resizable=1,left='+(window.screen.width-600)/2+',top='+(window.screen.height-700)/4);
    return false;
});
// タブ
$(document).ready(async function(){
//        let val = await eel.GetTabState()();
    let val = await window.api.invoke("GetTabState")
//        let chi = ['blowinj','blow','inj'];
    let chi = val + 1
//        let tabid = '#pills-tab a[href="#pills-'+ chi[val] +'"]';
    let tabid = '#pills-tab li:nth-child('+ chi +') a';
    $(tabid).tab('show'); // Select tab by name
});
// 予定編集リンク作成
 $(document).on('click', '.tab-content a', function() {
 let val = $(this).attr("href");
 const fn = function(){
   window.open(val,'_blank','width=600,height=750,scrollbars=1,location=0,menubar=0,toolbar=0,status=1,directories=0,resizable=1,left='+(window.screen.width-600)/2+',top='+(window.screen.height-700)/4)
 }
 setTimeout(fn,100);
 return false;
});
// ホーム
async function button_home(){
//      let val = await eel.PostDateNavi('',0)()
  let val = await window.api.invoke("PostDateNavi",{date:"",tabs:0})
}
// 予定印刷
async function printPDF(){
//      let val = await eel.GetPDF()((res) => {
  let val = await window.api.invoke("GetPDF")
  .then((res)=>{
    const fn = function(){
      window.open(res,'_blank','scrollbars=1,location=0,menubar=0,toolbar=0,status=1,directories=0,resizable=1')
    }
    setTimeout(fn,100)
  })
  .catch((err)=>{
    alert(err)
  })
}
// 子ウインドウからの更新処理
window.addEventListener('message', (e) => {
  window.location.reload()
})
